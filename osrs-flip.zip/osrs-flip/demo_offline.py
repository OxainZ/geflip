"""Offline end-to-end demo: no network required.

Generates a synthetic Grand Exchange with deliberately nasty items mixed in
(stale quotes, one-off outlier prints, thin books, unknown buy limits) and runs
the real scan -> allocate -> journal -> verify -> stats pipeline over it.

    python demo_offline.py

Use it to sanity-check changes to the scoring model without hammering the wiki.
"""

from __future__ import annotations

import random
import tempfile
import time
from pathlib import Path

from osrsflip import cli
from osrsflip.journal import Journal

random.seed(7)
NOW = time.time()


def build_market(n: int = 400):
    mapping, latest, hourly, daily, five = [], {}, {}, {}, {}

    for i in range(1, n + 1):
        base = random.choice([50, 500, 5_000, 120_000, 3_000_000, 60_000_000])
        base = int(base * random.uniform(0.6, 1.6))
        spread = random.uniform(0.002, 0.06)
        low = base
        high = int(base * (1 + spread))
        vol = int(random.lognormvariate(4.0, 1.6))
        limit = random.choice([8, 70, 125, 1_000, 10_000, 13_000])
        age = random.uniform(5, 900)

        # Deliberate landmines, one per category.
        if i % 37 == 0:      # stale quote
            age = random.uniform(4_000, 20_000)
        if i % 41 == 0:      # one-off outlier print
            high = int(base * 4)
        if i % 23 == 0:      # illiquid
            vol = random.randint(0, 4)
        if i % 53 == 0:      # unknown buy limit
            limit = None

        mapping.append({
            "id": i, "name": f"Item {i:03d}", "members": i % 5 != 0,
            "limit": limit, "highalch": int(base * 0.6), "lowalch": int(base * 0.4),
            "value": base,
        })
        latest[str(i)] = {
            "high": high, "highTime": int(NOW - age),
            "low": low, "lowTime": int(NOW - age * 1.2),
        }
        # The hourly VWAP reflects the *true* spread, so outlier prints get caught.
        true_high = int(base * (1 + min(spread, 0.05)))
        hourly[str(i)] = {
            "avgHighPrice": true_high, "highPriceVolume": vol,
            "avgLowPrice": low, "lowPriceVolume": int(vol * random.uniform(0.7, 1.3)),
        }
        daily[str(i)] = {
            "avgHighPrice": true_high, "highPriceVolume": vol * 22,
            "avgLowPrice": low, "lowPriceVolume": vol * 20,
        }
        five[str(i)] = {
            "avgHighPrice": true_high, "highPriceVolume": max(0, vol // 12),
            "avgLowPrice": low, "lowPriceVolume": max(0, vol // 12),
        }
    return mapping, latest, hourly, daily, five


MAPPING, LATEST, HOURLY, DAILY, FIVE = build_market()


class FakeClient:
    """Stands in for WikiPricesClient with zero network calls."""

    def mapping(self, **_):
        return MAPPING

    def latest(self, item_id=None):
        if item_id is not None:
            return {str(item_id): LATEST[str(item_id)]}
        return LATEST

    def window(self, timestep, timestamp=None):
        return {"1h": HOURLY, "24h": DAILY, "5m": FIVE}[timestep]

    #: History is anchored here so it overlaps the backdated journal entries.
    history_start = NOW - 86_400

    def timeseries(self, item_id, timestep="5m"):
        row = LATEST[str(item_id)]
        low, high = row["low"], row["high"]
        out = []
        for k in range(12):
            drift = random.uniform(0.985, 1.02)
            out.append({
                "timestamp": int(self.history_start + k * 300),
                "avgLowPrice": int(low * drift),
                "avgHighPrice": int(high * drift),
                "lowPriceVolume": random.randint(1, 400),
                "highPriceVolume": random.randint(1, 400),
            })
        return out


def main() -> None:
    cli._client = lambda args: FakeClient()  # noqa: SLF001 - demo injection point

    with tempfile.TemporaryDirectory() as tmp:
        db = str(Path(tmp) / "demo.sqlite3")
        cache = str(Path(tmp) / "cache")
        common = ["--db", db, "--cache-dir", cache]

        print("=" * 78)
        print("SCAN  (50m bankroll, 8 slots, members)")
        print("=" * 78)
        cli.main(common + ["scan", "--bankroll", "50m", "--slots", "8",
                           "--top", "10", "--offers"])

        print("\n" + "=" * 78)
        print("SCAN  (2m bankroll, 3 slots, f2p, 0.5% slippage)")
        print("=" * 78)
        cli.main(common + ["scan", "--bankroll", "2m", "--slots", "3", "--f2p",
                           "--slippage", "0.005", "--top", "8"])

        print("\n" + "=" * 78)
        print("BUY / LIMITS / BOOK / SELL")
        print("=" * 78)
        cli.main(common + ["buy", "Item 135", "10", "4.5m"])
        cli.main(common + ["limits"])
        cli.main(common + ["book", "--offline"])
        # Selling the position back out; pid 1 is the first logged buy.
        cli.main(common + ["sell", "1", "10", "4.7m"])
        cli.main(common + ["book", "--offline"])
        print("\n-- the scan now knows that limit is spent --")
        cli.main(common + ["scan", "--bankroll", "50m", "--top", "3", "--explain"])

        print("\n" + "=" * 78)
        print("VERIFY + STATS")
        print("=" * 78)
        # Age the journalled picks so they are eligible for verification.
        with Journal(db) as j:
            j.conn.execute("UPDATE recommendations SET recommended_at = ?",
                           (NOW - 86_400,))
            j.conn.commit()
        cli.main(common + ["verify", "--horizon", "1"])
        cli.main(common + ["stats"])

        print("\n" + "=" * 78)
        print("SCANS")
        print("=" * 78)
        cli.main(common + ["scans"])


if __name__ == "__main__":
    main()
