"""Test suite. Run with:  python -m unittest discover -s tests -v"""

from __future__ import annotations

import math
import tempfile
import unittest
from pathlib import Path

from osrsflip import fmt
from osrsflip.allocate import allocate
from osrsflip.journal import Journal
from osrsflip.models import (
    ItemMeta, LatestQuote, WindowStat, parse_latest, parse_mapping, parse_window,
)
from osrsflip.scoring import RejectionLog, ScanConfig, score_candidates
from osrsflip.tax import (
    GE_TAX_CAP, breakeven_sell_price, net_margin, net_proceeds, sale_tax,
)

NOW = 1_800_000_000.0


# --------------------------------------------------------------------- fixtures


def meta(item_id: int, name: str, limit: int | None = 1000, *,
         members: bool = True, alch: int | None = None, exempt: bool = False) -> ItemMeta:
    return ItemMeta(
        item_id=item_id, name=name, members=members, buy_limit=limit,
        high_alch=alch, low_alch=None, ge_value=None, tax_exempt=exempt,
    )


def quote(item_id: int, low: int, high: int, age: float = 60.0) -> LatestQuote:
    return LatestQuote(
        item_id=item_id, high=high, high_time=int(NOW - age),
        low=low, low_time=int(NOW - age),
    )


def window(item_id: int, avg_low: int | None, avg_high: int | None,
           low_vol: int = 500, high_vol: int = 500) -> WindowStat:
    return WindowStat(
        item_id=item_id, avg_high=avg_high, high_volume=high_vol,
        avg_low=avg_low, low_volume=low_vol,
    )


class TaxTests(unittest.TestCase):
    def test_rate_is_two_percent_floored(self):
        self.assertEqual(sale_tax(1_000_000), 20_000)
        self.assertEqual(sale_tax(60_000), 1_200)
        self.assertEqual(sale_tax(101), 2)

    def test_sub_fifty_gp_is_untaxed_by_rounding(self):
        for price in range(0, 50):
            self.assertEqual(sale_tax(price), 0, f"price {price}")
        self.assertEqual(sale_tax(50), 1)

    def test_cap_binds_at_250m(self):
        self.assertEqual(sale_tax(250_000_000), GE_TAX_CAP)
        self.assertEqual(sale_tax(1_800_000_000), GE_TAX_CAP)
        self.assertEqual(sale_tax(249_999_999), 4_999_999)

    def test_exemption(self):
        self.assertEqual(sale_tax(10_000_000, exempt=True), 0)
        self.assertEqual(net_proceeds(10_000_000, exempt=True), 10_000_000)

    def test_integer_math_matches_exact_floor_on_large_prices(self):
        # float(price) * 0.02 misrounds here; integer arithmetic must not.
        price = 1_799_999_999
        self.assertEqual(price * 2 // 100, 35_999_999)
        self.assertEqual(sale_tax(price), GE_TAX_CAP)  # capped anyway
        self.assertEqual(sale_tax(100_000_003), 2_000_000)

    def test_net_margin_can_be_negative(self):
        # 2% of 1,010,000 is 20,200, which swallows the whole 10k gross spread.
        self.assertEqual(net_margin(1_000_000, 1_010_000), -10_200)
        self.assertGreater(net_margin(1_000_000, 1_010_000, exempt=True), 0)

    def test_breakeven_round_trips(self):
        for buy in (1, 49, 50, 51, 999, 100_000, 1_000_000, 249_000_000, 400_000_000):
            be = breakeven_sell_price(buy)
            self.assertGreaterEqual(net_proceeds(be), buy, f"buy={buy}")
            if be > 0:
                self.assertLess(net_proceeds(be - 1), buy, f"buy={buy} not minimal")

    def test_breakeven_exempt_is_identity(self):
        self.assertEqual(breakeven_sell_price(12_345, exempt=True), 12_345)

    def test_negative_price_rejected(self):
        with self.assertRaises(ValueError):
            sale_tax(-1)


class ModelTests(unittest.TestCase):
    def test_mapping_skips_malformed_rows(self):
        rows = [
            {"id": 4151, "name": "Abyssal whip", "limit": 70, "members": True},
            {"id": None, "name": "Broken"},
            {"name": "No id"},
            {"id": 561, "name": "Nature rune", "limit": 12000, "members": False},
        ]
        parsed = parse_mapping(rows)
        self.assertEqual(set(parsed), {4151, 561})
        self.assertEqual(parsed[4151].buy_limit, 70)

    def test_mapping_marks_exempt_items(self):
        parsed = parse_mapping([{"id": 13190, "name": "Old school bond", "limit": 100}])
        self.assertTrue(parsed[13190].tax_exempt)

    def test_missing_buy_limit_is_none_not_zero(self):
        parsed = parse_mapping([{"id": 1, "name": "Thing"}])
        self.assertIsNone(parsed[1].buy_limit)

    def test_latest_handles_one_sided_quotes(self):
        parsed = parse_latest({"5": {"high": 100, "highTime": 1, "low": None, "lowTime": None}})
        self.assertFalse(parsed[5].two_sided)
        self.assertIsNone(parsed[5].staleness_s(NOW))

    def test_staleness_uses_the_older_side(self):
        q = LatestQuote(1, high=10, high_time=int(NOW - 10),
                        low=9, low_time=int(NOW - 500))
        self.assertAlmostEqual(q.staleness_s(NOW), 500.0)

    def test_window_two_sided_volume_is_the_binding_side(self):
        parsed = parse_window({"7": {"avgHighPrice": 10, "highPriceVolume": 10_000,
                                     "avgLowPrice": 9, "lowPriceVolume": 3}})
        self.assertEqual(parsed[7].two_sided_volume, 3)
        self.assertEqual(parsed[7].total_volume, 10_003)

    def test_window_null_volume_becomes_zero(self):
        parsed = parse_window({"7": {"avgHighPrice": None, "highPriceVolume": None,
                                     "avgLowPrice": None, "lowPriceVolume": None}})
        self.assertEqual(parsed[7].two_sided_volume, 0)


class ScoringTests(unittest.TestCase):
    def setUp(self):
        self.mapping = {
            1: meta(1, "Good flip", limit=1000),
            2: meta(2, "Thin item", limit=1000),
            3: meta(3, "Stale item", limit=1000),
            4: meta(4, "Members only", limit=1000, members=True),
            5: meta(5, "No limit", limit=None),
            6: meta(6, "Outlier print", limit=1000),
        }
        self.latest = {
            1: quote(1, 1_000, 1_100),
            2: quote(2, 1_000, 1_100),
            3: quote(3, 1_000, 1_100, age=7_200),
            4: quote(4, 1_000, 1_100),
            5: quote(5, 1_000, 1_100),
            6: quote(6, 1_000, 5_000),
        }
        self.hourly = {
            1: window(1, 1_000, 1_100),
            2: window(2, 1_000, 1_100, low_vol=2, high_vol=2),
            3: window(3, 1_000, 1_100),
            4: window(4, 1_000, 1_100),
            5: window(5, 1_000, 1_100),
            6: window(6, 1_000, 1_060),  # hourly says the 5k print was noise
        }
        self.cfg = ScanConfig(bankroll=10_000_000, min_daily_volume=0)

    def _score(self, cfg=None, **kwargs):
        rej = RejectionLog()
        out = score_candidates(
            self.mapping, self.latest, self.hourly, {}, {},
            cfg or self.cfg, now=NOW, rejections=rej, **kwargs,
        )
        return {c.item_id: c for c in out}, rej

    def test_healthy_item_survives(self):
        got, _ = self._score()
        self.assertIn(1, got)
        c = got[1]
        self.assertEqual(c.margin, 1_100 - 22 - 1_000)  # 2% of 1100 = 22
        self.assertGreater(c.expected_gp_per_hour, 0)

    def test_thin_item_rejected_on_hourly_volume(self):
        got, rej = self._score()
        self.assertNotIn(2, got)
        self.assertIn("hourly volume too thin", rej.counts)

    def test_stale_quote_rejected(self):
        got, rej = self._score()
        self.assertNotIn(3, got)
        self.assertIn("quote too stale", rej.counts)

    def test_f2p_excludes_members_items(self):
        cfg = ScanConfig(bankroll=10_000_000, members=False, min_daily_volume=0)
        got, rej = self._score(cfg)
        self.assertEqual(got, {})
        self.assertIn("members item on f2p account", rej.counts)

    def test_unknown_buy_limit_skipped_by_default(self):
        got, rej = self._score()
        self.assertNotIn(5, got)
        self.assertIn("unknown buy limit", rej.counts)

    def test_unknown_buy_limit_can_be_assumed(self):
        cfg = ScanConfig(bankroll=10_000_000, min_daily_volume=0, unknown_limit_default=50)
        got, _ = self._score(cfg)
        self.assertIn(5, got)
        self.assertEqual(got[5].buy_limit, 50)

    def test_outlier_print_is_priced_off_the_hourly_vwap(self):
        """The whole point: item 6 quotes a 4k spread but the hour says ~10gp."""
        got, _ = self._score()
        self.assertIn(6, got)
        c6, c1 = got[6], got[1]
        self.assertLess(c6.margin, 100)
        self.assertLess(c6.stability, 0.2)
        self.assertLess(c6.expected_gp_per_hour, c1.expected_gp_per_hour)

    def test_throughput_caps_quantity_below_buy_limit(self):
        got, _ = self._score()
        expected = int(self.cfg.participation * 500 * self.cfg.cycle_hours)
        self.assertEqual(got[1].quantity, expected)
        self.assertLess(expected, 1000, "throughput must bind before the buy limit")
        self.assertEqual(got[1].limiting_factor, "market throughput")

    def test_capital_can_be_the_binding_constraint(self):
        cfg = ScanConfig(bankroll=50_000, min_daily_volume=0,
                         max_capital_fraction_per_item=1.0)
        got, _ = self._score(cfg)
        self.assertEqual(got[1].quantity, 50)
        self.assertEqual(got[1].limiting_factor, "capital")

    def test_default_concentration_cap_limits_a_single_position(self):
        # 25% of a 50k bank is 12.5k, so only 12 units at 1000gp each.
        cfg = ScanConfig(bankroll=50_000, min_daily_volume=0)
        got, _ = self._score(cfg)
        self.assertEqual(got[1].quantity, 12)
        self.assertEqual(got[1].limiting_factor, "capital")

    def test_buy_limit_can_be_the_binding_constraint(self):
        self.mapping[1] = meta(1, "Good flip", limit=10)
        got, _ = self._score()
        self.assertEqual(got[1].quantity, 10)
        self.assertEqual(got[1].limiting_factor, "buy limit")

    def test_slippage_moves_both_sides_adversely(self):
        cfg = ScanConfig(bankroll=10_000_000, min_daily_volume=0, slippage=0.01)
        got, _ = self._score(cfg)
        c = got.get(1)
        self.assertIsNotNone(c)
        self.assertEqual(c.buy_price, 1_010)   # ceil(1000 * 1.01)
        self.assertEqual(c.sell_price, 1_089)  # floor(1100 * 0.99)

    def test_freshness_decays_with_age(self):
        self.latest[1] = quote(1, 1_000, 1_100, age=1_200)  # one tau
        got, _ = self._score()
        self.assertAlmostEqual(got[1].freshness, 0.3679, places=3)

    def test_missing_hourly_window_gets_haircut_not_free_pass(self):
        # Degenerate window: volume reported but no average prices to corroborate
        # the spread. We must not treat the raw /latest spread as verified.
        cfg = ScanConfig(bankroll=10_000_000, min_daily_volume=0, unverified_haircut=0.5)
        self.hourly[1] = window(1, None, None)
        got, _ = self._score(cfg)
        self.assertEqual(got[1].margin, (1_100 - 22 - 1_000) // 2)
        self.assertIsNone(got[1].hourly_margin)
        self.assertEqual(got[1].stability, 0.5)

    def test_item_absent_from_hourly_window_is_dropped(self):
        # No trades in the last hour means no throughput estimate, so no position.
        self.hourly.pop(1)
        got, rej = self._score()
        self.assertNotIn(1, got)
        self.assertIn("hourly volume too thin", rej.counts)

    def test_daily_volume_gate_applies_only_when_supplied(self):
        rej = RejectionLog()
        cfg = ScanConfig(bankroll=10_000_000, min_daily_volume=10_000)
        daily = {1: window(1, 1_000, 1_100, low_vol=5, high_vol=5)}
        out = score_candidates(self.mapping, self.latest, self.hourly, daily, {},
                               cfg, now=NOW, rejections=rej)
        self.assertNotIn(1, {c.item_id for c in out})
        self.assertIn("daily volume too thin", rej.counts)

    def test_results_are_sorted_by_expected_gp_per_hour(self):
        out = score_candidates(self.mapping, self.latest, self.hourly, {}, {},
                               self.cfg, now=NOW)
        values = [c.expected_gp_per_hour for c in out]
        self.assertEqual(values, sorted(values, reverse=True))

    def test_alch_cushion_uses_live_nature_rune_price(self):
        self.mapping[561] = meta(561, "Nature rune", limit=12_000, members=False)
        self.latest[561] = quote(561, 100, 110)
        self.hourly[561] = window(561, 100, 110)
        self.mapping[1] = meta(1, "Good flip", limit=1000, alch=1_500)
        got, _ = self._score()
        # (1500 high alch - 110 nature - 1000 buy) / 1000
        self.assertAlmostEqual(got[1].alch_cushion, 0.39, places=6)

    def test_config_validation(self):
        for kwargs in ({"slippage": 0.9}, {"participation": 0}, {"slots": 0},
                       {"bankroll": -1}, {"cycle_hours": 0}, {"volume_saturation": 0}):
            with self.assertRaises(ValueError, msg=str(kwargs)):
                ScanConfig(**kwargs)


class AllocationTests(unittest.TestCase):
    def _cands(self, cfg, mapping, latest, hourly):
        return score_candidates(mapping, latest, hourly, {}, {}, cfg, now=NOW)

    def test_allocation_respects_slot_and_capital_limits(self):
        mapping = {i: meta(i, f"Item {i}", limit=1000) for i in range(1, 21)}
        latest = {i: quote(i, 1_000 * i, int(1_000 * i * 1.10)) for i in range(1, 21)}
        hourly = {i: window(i, 1_000 * i, int(1_000 * i * 1.10)) for i in range(1, 21)}
        cfg = ScanConfig(bankroll=5_000_000, slots=4, min_daily_volume=0)
        cands = self._cands(cfg, mapping, latest, hourly)

        alloc = allocate(cands, bankroll=cfg.bankroll, slots=cfg.slots)
        self.assertLessEqual(alloc.slots_used, 4)
        self.assertLessEqual(alloc.capital_deployed, cfg.bankroll)
        self.assertGreater(alloc.expected_gp_per_hour, 0)
        self.assertEqual(len({p.candidate.item_id for p in alloc.positions}),
                         alloc.slots_used, "no duplicate items across slots")

    def test_allocation_prefers_capacity_when_slots_are_scarce(self):
        """A tiny high-ROI item must not monopolise the only slot available."""
        mapping = {
            1: meta(1, "Tiny high roi", limit=5),
            2: meta(2, "Big absorber", limit=10_000),
        }
        latest = {1: quote(1, 100, 200), 2: quote(2, 1_000, 1_100)}
        hourly = {
            1: window(1, 100, 200, low_vol=10_000, high_vol=10_000),
            2: window(2, 1_000, 1_100, low_vol=10_000, high_vol=10_000),
        }
        cfg = ScanConfig(bankroll=10_000_000, slots=1, min_daily_volume=0)
        cands = self._cands(cfg, mapping, latest, hourly)
        alloc = allocate(cands, bankroll=cfg.bankroll, slots=1)
        self.assertEqual(alloc.slots_used, 1)
        self.assertEqual(alloc.positions[0].candidate.item_id, 2)

    def test_allocation_respects_concentration_cap(self):
        """One item must not be able to eat the whole bankroll when capped."""
        mapping = {i: meta(i, f"Item {i}", limit=10_000) for i in (1, 2, 3)}
        latest = {i: quote(i, 1_000, 1_100) for i in (1, 2, 3)}
        hourly = {i: window(i, 1_000, 1_100, low_vol=100_000, high_vol=100_000)
                  for i in (1, 2, 3)}
        cfg = ScanConfig(bankroll=10_000_000, slots=3, min_daily_volume=0)
        cands = self._cands(cfg, mapping, latest, hourly)

        uncapped = allocate(cands, bankroll=10_000_000, slots=3)
        self.assertGreater(max(p.capital for p in uncapped.positions), 4_000_000)

        capped = allocate(cands, bankroll=10_000_000, slots=3, max_item_fraction=0.34)
        self.assertLessEqual(max(p.capital for p in capped.positions), 3_400_000)
        self.assertEqual(capped.slots_used, 3)

    def test_allocation_rejects_bad_fraction(self):
        with self.assertRaises(ValueError):
            allocate([], bankroll=1, slots=1, max_item_fraction=1.5)

    def test_empty_inputs_are_safe(self):
        self.assertEqual(allocate([], bankroll=1_000_000, slots=8).positions, [])
        self.assertEqual(allocate([], bankroll=0, slots=8).expected_gp_per_hour, 0)

    def test_zero_bankroll_deploys_nothing(self):
        mapping = {1: meta(1, "Item", limit=100)}
        latest = {1: quote(1, 1_000, 1_100)}
        hourly = {1: window(1, 1_000, 1_100)}
        cfg = ScanConfig(bankroll=1_000_000, min_daily_volume=0)
        cands = self._cands(cfg, mapping, latest, hourly)
        self.assertEqual(allocate(cands, bankroll=0, slots=8).capital_deployed, 0)


class JournalTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Path(self.tmp.name) / "j.sqlite3"
        self.mapping = {1: meta(1, "Item", limit=1000)}
        self.latest = {1: quote(1, 1_000, 1_100)}
        self.hourly = {1: window(1, 1_000, 1_100)}
        self.cfg = ScanConfig(bankroll=10_000_000, min_daily_volume=0)
        self.cands = score_candidates(self.mapping, self.latest, self.hourly,
                                      {}, {}, self.cfg, now=NOW)

    def tearDown(self):
        self.tmp.cleanup()

    def test_record_and_read_back(self):
        with Journal(self.db) as j:
            alloc = allocate(self.cands, bankroll=self.cfg.bankroll, slots=8)
            scan_id = j.record_scan(self.cands, self.cfg, alloc, now=NOW)
            self.assertGreater(scan_id, 0)
            rows = list(j.conn.execute("SELECT * FROM recommendations"))
            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0]["allocated"], 1)
            self.assertEqual(len(j.recent_scans()), 1)

    def test_verify_marks_a_completed_round_trip(self):
        series = [
            {"timestamp": int(NOW + 300), "avgLowPrice": 995, "avgHighPrice": 1_050,
             "lowPriceVolume": 100, "highPriceVolume": 100},
            {"timestamp": int(NOW + 600), "avgLowPrice": 1_010, "avgHighPrice": 1_150,
             "lowPriceVolume": 100, "highPriceVolume": 100},
        ]
        with Journal(self.db) as j:
            j.record_scan(self.cands, self.cfg, None, now=NOW)
            result = j.verify(lambda item_id, step: series,
                              horizon_hours=1.0, now=NOW + 7_200)
            self.assertEqual(result["checked"], 1)
            self.assertEqual(result["filled"], 1)
            out = list(j.conn.execute("SELECT * FROM outcomes"))[0]
            self.assertEqual(out["best_sell"], 1_150)
            self.assertEqual(out["realized_margin"], 1_150 - 23 - 1_000)

    def test_verify_detects_an_unfillable_sell(self):
        series = [{"timestamp": int(NOW + 300), "avgLowPrice": 990,
                   "avgHighPrice": 1_005, "lowPriceVolume": 10, "highPriceVolume": 10}]
        with Journal(self.db) as j:
            j.record_scan(self.cands, self.cfg, None, now=NOW)
            j.verify(lambda i, s: series, horizon_hours=1.0, now=NOW + 7_200)
            out = list(j.conn.execute("SELECT * FROM outcomes"))[0]
            self.assertTrue(out["buy_filled"])
            self.assertFalse(out["sell_filled"])

    def test_verify_ignores_windows_before_the_recommendation(self):
        series = [{"timestamp": int(NOW - 3_600), "avgLowPrice": 900,
                   "avgHighPrice": 2_000, "lowPriceVolume": 10, "highPriceVolume": 10}]
        with Journal(self.db) as j:
            j.record_scan(self.cands, self.cfg, None, now=NOW)
            result = j.verify(lambda i, s: series, horizon_hours=1.0, now=NOW + 7_200)
            self.assertEqual(result["no_data"], 1)

    def test_verify_survives_a_failing_fetch(self):
        def boom(item_id, step):
            raise RuntimeError("network down")

        with Journal(self.db) as j:
            j.record_scan(self.cands, self.cfg, None, now=NOW)
            result = j.verify(boom, horizon_hours=1.0, now=NOW + 7_200)
            self.assertEqual(result["no_data"], 1)
            out = list(j.conn.execute("SELECT * FROM outcomes"))[0]
            self.assertIn("network down", out["note"])

    def test_failed_fetch_is_counted_once_per_recommendation(self):
        """Regression: the error path used to add len(recs) per row, so N recs
        for one item reported N-squared failures."""
        def boom(item_id, step):
            raise RuntimeError("nope")

        with Journal(self.db) as j:
            j.record_scan(self.cands, self.cfg, None, now=NOW)
            j.record_scan(self.cands, self.cfg, None, now=NOW + 1)
            j.record_scan(self.cands, self.cfg, None, now=NOW + 2)
            result = j.verify(boom, horizon_hours=1.0, now=NOW + 7_200)
            self.assertEqual(result["no_data"], 3)

    def test_journal_persists_tax_exemption_flag(self):
        self.mapping[1] = meta(1, "Old school bond", limit=100, exempt=True)
        cands = score_candidates(self.mapping, self.latest, self.hourly, {}, {},
                                 self.cfg, now=NOW)
        with Journal(self.db) as j:
            j.record_scan(cands, self.cfg, None, now=NOW)
            row = list(j.conn.execute("SELECT tax_exempt FROM recommendations"))[0]
            self.assertEqual(row["tax_exempt"], 1)

    def test_verify_is_idempotent(self):
        series = [{"timestamp": int(NOW + 300), "avgLowPrice": 995,
                   "avgHighPrice": 1_150, "lowPriceVolume": 10, "highPriceVolume": 10}]
        with Journal(self.db) as j:
            j.record_scan(self.cands, self.cfg, None, now=NOW)
            j.verify(lambda i, s: series, horizon_hours=1.0, now=NOW + 7_200)
            second = j.verify(lambda i, s: series, horizon_hours=1.0, now=NOW + 7_200)
            self.assertEqual(second["checked"], 0)

    def test_stats_reports_predicted_and_realized(self):
        series = [{"timestamp": int(NOW + 300), "avgLowPrice": 995,
                   "avgHighPrice": 1_150, "lowPriceVolume": 10, "highPriceVolume": 10}]
        with Journal(self.db) as j:
            j.record_scan(self.cands, self.cfg, None, now=NOW)
            j.verify(lambda i, s: series, horizon_hours=1.0, now=NOW + 7_200)
            stats = j.stats()
            self.assertEqual(stats["observations"], 1)
            self.assertEqual(stats["buy_fill_rate"], 1.0)
            self.assertGreater(stats["mean_realized_roi"], 0)

    def test_stats_with_no_data(self):
        with Journal(self.db) as j:
            self.assertEqual(j.stats()["observations"], 0)


class FormatTests(unittest.TestCase):
    def test_gp_abbreviation(self):
        self.assertEqual(fmt.gp(999), "999")
        self.assertEqual(fmt.gp(1_500), "1.50k")
        self.assertEqual(fmt.gp(1_234_567), "1.23m")
        self.assertEqual(fmt.gp(2_100_000_000), "2.10b")
        self.assertEqual(fmt.gp(-5_000), "-5.00k")

    def test_parse_gp_round_trip(self):
        self.assertEqual(fmt.parse_gp("50m"), 50_000_000)
        self.assertEqual(fmt.parse_gp("1.2b"), 1_200_000_000)
        self.assertEqual(fmt.parse_gp("750k"), 750_000)
        self.assertEqual(fmt.parse_gp("2,500"), 2_500)
        self.assertEqual(fmt.parse_gp("42"), 42)

    def test_parse_gp_rejects_junk(self):
        for bad in ("", "abc", "-5m", "1..2m"):
            with self.assertRaises(ValueError, msg=bad):
                fmt.parse_gp(bad)

    def test_table_handles_empty_and_ragged(self):
        self.assertIn("no rows", fmt.table(["a", "b"], []))
        rendered = fmt.table(["a", "b"], [["x", "1"], ["yy", "22"]])
        self.assertIn("yy", rendered)

    def test_duration(self):
        self.assertEqual(fmt.duration(45), "45s")
        self.assertEqual(fmt.duration(600), "10m")
        self.assertEqual(fmt.duration(7_200), "2.0h")


class ApiConfigTests(unittest.TestCase):
    def test_placeholder_user_agent_rejected(self):
        from osrsflip.api import ClientConfig
        for bad in ("", "  ", "changeme", "python-urllib"):
            with self.assertRaises(ValueError, msg=bad):
                ClientConfig(user_agent=bad)

    def test_bad_game_rejected(self):
        from osrsflip.api import ClientConfig
        with self.assertRaises(ValueError):
            ClientConfig(user_agent="tool - me@example.com", game="rs3")

    def test_url_building(self):
        from osrsflip.api import ClientConfig, WikiPricesClient
        c = WikiPricesClient(ClientConfig(user_agent="tool - me@example.com"))
        self.assertEqual(
            c._build_url("timeseries", {"timestep": "5m", "id": 4151}),
            "https://prices.runescape.wiki/api/v1/osrs/timeseries?timestep=5m&id=4151",
        )
        self.assertEqual(
            c._build_url("latest", {"id": None}),
            "https://prices.runescape.wiki/api/v1/osrs/latest",
        )


if __name__ == "__main__":
    unittest.main(verbosity=2)


# ===================== v2: parity with the web app =========================

from osrsflip.book import (  # noqa: E402
    LIMIT_WINDOW_S, Position, blend_sale, limit_for, limit_group, limit_map,
    position_pnl, rolling_reset_schedule,
)
from osrsflip.scoring import tick_size  # noqa: E402

H = 3600


def held(item_id, name, qty, at, price=1000, sold=0, sell=None, exempt=False):
    return Position(pid=item_id * 1000 + int(at) % 1000, item_id=item_id, name=name,
                    qty=qty, buy_price=price, bought_at=at, sold_qty=sold,
                    sell_price=sell, tax_exempt=exempt)


class TickTests(unittest.TestCase):
    def test_tick_matches_the_web_engine(self):
        self.assertEqual(tick_size(5), 1)
        self.assertEqual(tick_size(1_000), 1)
        self.assertEqual(tick_size(100_000), 50)
        self.assertEqual(tick_size(10_000_000), 5_000)

    def test_tick_never_zero(self):
        for price in (1, 2, 999):
            self.assertGreaterEqual(tick_size(price), 1)


class LimitGroupTests(unittest.TestCase):
    def test_dose_variants_group(self):
        for name in ("Prayer potion(1)", "Prayer potion(4)", "Prayer potion (3)"):
            self.assertEqual(limit_group(name), "prayer potion", name)

    def test_cosmetic_suffixes_do_not_group(self):
        self.assertEqual(limit_group("Rune platebody (g)"), "rune platebody (g)")
        self.assertEqual(limit_group("Amulet of fury (or)"), "amulet of fury (or)")

    def test_plain_and_empty_names(self):
        self.assertEqual(limit_group("Teak plank"), "teak plank")
        self.assertEqual(limit_group(""), "")
        self.assertEqual(limit_group(None), "")


class BuyLimitWindowTests(unittest.TestCase):
    def test_window_is_four_hours(self):
        self.assertEqual(LIMIT_WINDOW_S, 4 * 3600)

    def test_nothing_bought(self):
        st = limit_for([], 1, 13_000, 0)
        self.assertEqual(st.remaining, 13_000)
        self.assertFalse(st.is_open)

    def test_partial_spend(self):
        st = limit_for([held(1, "Teak plank", 5_000, 0)], 1, 13_000, H)
        self.assertEqual((st.spent, st.remaining), (5_000, 8_000))
        self.assertEqual(st.reset_at, LIMIT_WINDOW_S)

    def test_timer_anchors_to_the_first_buy(self):
        pos = [held(1, "Teak plank", 1_000, 0), held(1, "Teak plank", 12_000, 3.9 * H)]
        st = limit_for(pos, 1, 13_000, 3.95 * H)
        self.assertEqual(st.spent, 13_000)
        self.assertEqual(st.reset_at, LIMIT_WINDOW_S, "anchored to the FIRST buy")

    def test_full_reset_even_right_after_a_large_late_buy(self):
        """The divergence a rolling 4h sum gets wrong."""
        pos = [held(1, "Teak plank", 1_000, 0), held(1, "Teak plank", 12_000, 3.9 * H)]
        st = limit_for(pos, 1, 13_000, 4.05 * H)
        self.assertEqual(st.spent, 0)
        self.assertEqual(st.remaining, 13_000)
        naive = sum(p.qty for p in pos if 4.05 * H - p.bought_at < LIMIT_WINDOW_S)
        self.assertEqual(naive, 12_000)
        self.assertNotEqual(naive, st.spent)

    def test_consecutive_windows_do_not_bleed(self):
        pos = [held(1, "X", 13_000, 0), held(1, "X", 2_000, 4.5 * H)]
        st = limit_for(pos, 1, 13_000, 5 * H)
        self.assertEqual(st.spent, 2_000)
        self.assertEqual(st.reset_at, 4.5 * H + LIMIT_WINDOW_S)


class ConnectedLimitTests(unittest.TestCase):
    def setUp(self):
        self.mapping = {
            139: meta(139, "Prayer potion(1)", limit=2000),
            141: meta(141, "Prayer potion(2)", limit=2000),
            143: meta(143, "Prayer potion(4)", limit=2000),
            1: meta(1, "Teak plank", limit=13000),
        }

    def test_buying_one_dose_exhausts_the_family(self):
        states = limit_map([held(143, "Prayer potion(4)", 2000, NOW - 600)],
                           self.mapping, NOW)
        for item_id in (139, 141, 143):
            self.assertEqual(states[item_id].remaining, 0, item_id)
        self.assertTrue(states[139].shared)
        self.assertNotIn(1, states, "unrelated item untouched")

    def test_mixed_doses_share_one_allowance(self):
        pos = [held(143, "Prayer potion(4)", 500, NOW - 600),
               held(139, "Prayer potion(1)", 700, NOW - 300)]
        self.assertEqual(limit_map(pos, self.mapping, NOW)[141].remaining, 800)

    def test_name_resolved_from_mapping_when_missing(self):
        pos = [Position(pid=1, item_id=143, name="", qty=2000, buy_price=10_000,
                        bought_at=NOW - 600)]
        self.assertEqual(limit_map(pos, self.mapping, NOW)[139].remaining, 0)

    def test_group_allowance_resets(self):
        pos = [held(143, "Prayer potion(4)", 2000, NOW - 5 * H)]
        self.assertEqual(limit_map(pos, self.mapping, NOW)[139].remaining, 2000)

    def test_schedule_sorted_by_soonest_reset(self):
        pos = [held(1, "Teak plank", 100, NOW - 3 * H),
               held(143, "Prayer potion(4)", 100, NOW - 600)]
        rows = rolling_reset_schedule(pos, self.mapping, NOW)
        self.assertEqual(rows[0][0], "Teak plank", "soonest reset first")


class ScanLimitIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.mapping = {1: meta(1, "Teak plank", limit=13000)}
        self.latest = {1: quote(1, 800, 825)}
        self.hourly = {1: window(1, 799, 824, low_vol=50_000, high_vol=50_000)}
        self.cfg = ScanConfig(bankroll=50_000_000, min_daily_volume=0,
                              max_capital_fraction_per_item=1.0)

    def _score(self, limits=None):
        rej = RejectionLog()
        out = score_candidates(self.mapping, self.latest, self.hourly, {}, {},
                               self.cfg, now=NOW, rejections=rej, limits=limits)
        return out, rej

    def test_full_limit_with_no_positions(self):
        out, _ = self._score()
        self.assertEqual(out[0].quantity, 13_000)

    def test_exhausted_item_is_dropped(self):
        limits = limit_map([held(1, "Teak plank", 13_000, NOW - 600)], self.mapping, NOW)
        out, rej = self._score(limits)
        self.assertEqual(out, [])
        self.assertEqual(rej.counts["buy limit already spent"], 1)

    def test_quantity_capped_to_remaining(self):
        limits = limit_map([held(1, "Teak plank", 10_000, NOW - 600)], self.mapping, NOW)
        out, _ = self._score(limits)
        self.assertEqual(out[0].quantity, 3_000)
        self.assertEqual(out[0].limit_total, 13_000)
        self.assertGreater(out[0].limit_reset_at, NOW)

    def test_item_returns_after_the_window(self):
        limits = limit_map([held(1, "Teak plank", 13_000, NOW - 5 * H)], self.mapping, NOW)
        out, _ = self._score(limits)
        self.assertEqual(out[0].quantity, 13_000)


class OfferPriceTests(unittest.TestCase):
    def setUp(self):
        self.mapping = {1: meta(1, "Thing", limit=10_000)}
        self.cfg = ScanConfig(bankroll=100_000_000, min_daily_volume=0,
                              max_capital_fraction_per_item=1.0)

    def _one(self, low, high, vol=500):
        out = score_candidates(self.mapping, {1: quote(1, low, high)},
                               {1: window(1, low, high, low_vol=vol, high_vol=vol)},
                               {}, {}, self.cfg, now=NOW)
        return out[0]

    def test_competitive_sits_one_tick_inside(self):
        c = self._one(1_000, 1_100)
        self.assertEqual(c.bid_competitive, 1_001)
        self.assertEqual(c.ask_competitive, 1_099)

    def test_competitive_margin_identity(self):
        c = self._one(1_000, 1_100)
        self.assertEqual(
            c.margin_competitive,
            net_margin(c.bid_competitive, c.ask_competitive) - (c.instant_margin - c.margin),
        )
        self.assertLess(c.margin_competitive, c.margin)

    def test_never_crosses_on_a_one_gp_spread(self):
        c = self._one(5, 6, vol=9_000)
        self.assertGreater(c.ask_competitive, c.bid_competitive)

    def test_margin_check_cost(self):
        c = self._one(1_000, 1_100)
        self.assertEqual(c.margin_check_cost, 1_100 - 1_000 + sale_tax(1_000))


class FlowAndTrendTests(unittest.TestCase):
    def setUp(self):
        self.mapping = {1: meta(1, "Thing", limit=10_000)}
        self.cfg = ScanConfig(bankroll=100_000_000, min_daily_volume=0,
                              max_capital_fraction_per_item=1.0)

    def _one(self, hourly, daily=None):
        return score_candidates(self.mapping, {1: quote(1, 1_000, 1_100)},
                                hourly, daily or {}, {}, self.cfg, now=NOW)[0]

    def test_thin_buy_side_makes_sell_the_bottleneck(self):
        c = self._one({1: window(1, 1_000, 1_100, low_vol=4_000, high_vol=100)})
        self.assertEqual(c.bottleneck, "sell")
        self.assertGreater(c.fill_sell_minutes, c.fill_buy_minutes)
        self.assertGreater(c.flow_skew, 0.9)

    def test_thin_sell_side_makes_buy_the_bottleneck(self):
        c = self._one({1: window(1, 1_000, 1_100, low_vol=100, high_vol=4_000)})
        self.assertEqual(c.bottleneck, "buy")
        self.assertLess(c.flow_skew, -0.9)

    def test_fill_time_formula(self):
        c = self._one({1: window(1, 1_000, 1_100, low_vol=1_000, high_vol=1_000)})
        p = self.cfg.participation
        self.assertEqual(c.quantity, int(p * 1_000 * self.cfg.cycle_hours))
        self.assertAlmostEqual(c.fill_buy_minutes, (c.quantity / (1_000 * p)) * 60)

    def test_falling_knife_is_penalised(self):
        c = self._one({1: window(1, 1_150, 1_250)})
        self.assertLess(c.trend_1h, -0.1)
        self.assertLess(c.confidence, 0.8)

    def test_rising_price_is_not_penalised(self):
        rising = self._one({1: window(1, 900, 1_000)})
        self.assertGreater(rising.trend_1h, 0.05)
        # No knife factor. Freshness and volume are averaged geometrically;
        # stability remains a hard multiplier.
        self.assertAlmostEqual(
            rising.confidence,
            math.sqrt(rising.freshness * rising.volume_score) * rising.stability,
            places=9)

    def test_knife_penalty_is_exactly_the_configured_factor(self):
        falling = self._one({1: window(1, 1_150, 1_250)})
        self.assertAlmostEqual(
            falling.confidence,
            math.sqrt(falling.freshness * falling.volume_score)
            * falling.stability * 0.8,
            places=9)


class CapitalEfficiencyTests(unittest.TestCase):
    def test_small_high_return_flip_beats_a_big_absorber_per_gp(self):
        mapping = {1: meta(1, "Teak plank", limit=13_000),
                   2: meta(2, "Fire rune", limit=50_000, members=False)}
        latest = {1: quote(1, 800, 825), 2: quote(2, 5, 6)}
        hourly = {1: window(1, 799, 824, low_vol=50_000, high_vol=50_000),
                  2: window(2, 5, 6, low_vol=900_000, high_vol=900_000)}
        cfg = ScanConfig(bankroll=50_000_000, min_daily_volume=0,
                         max_capital_fraction_per_item=1.0)
        out = {c.item_id: c for c in
               score_candidates(mapping, latest, hourly, {}, {}, cfg, now=NOW)}
        plank, rune = out[1], out[2]
        self.assertGreater(plank.expected_gp_per_hour, rune.expected_gp_per_hour)
        self.assertGreater(rune.roi_per_hour, plank.roi_per_hour)
        self.assertGreater(rune.gp_per_million, plank.gp_per_million * 5)
        self.assertAlmostEqual(rune.gp_per_million, rune.roi_per_hour * 1_000_000)

    def test_concentration_cap_binds(self):
        mapping = {i: meta(i, f"Item {i}", limit=10_000) for i in (1, 2, 3)}
        latest = {i: quote(i, 1_000, 1_100) for i in (1, 2, 3)}
        hourly = {i: window(i, 1_000, 1_100, low_vol=100_000, high_vol=100_000)
                  for i in (1, 2, 3)}
        cfg = ScanConfig(bankroll=10_000_000, slots=3, min_daily_volume=0,
                         max_capital_fraction_per_item=1.0)
        cands = score_candidates(mapping, latest, hourly, {}, {}, cfg, now=NOW)
        capped = allocate(cands, bankroll=10_000_000, slots=3, max_item_fraction=0.34)
        self.assertLessEqual(max(p.capital for p in capped.positions), 3_400_000)

    def test_default_config_caps_concentration(self):
        self.assertEqual(ScanConfig().max_capital_fraction_per_item, 0.25)

    def test_binding_constraint_names_the_scarce_resource(self):
        mapping = {1: meta(1, "Small", limit=10)}
        latest = {1: quote(1, 100, 130)}
        hourly = {1: window(1, 100, 130, low_vol=10_000, high_vol=10_000)}
        cfg = ScanConfig(bankroll=100_000_000, slots=8, min_daily_volume=0)
        cands = score_candidates(mapping, latest, hourly, {}, {}, cfg, now=NOW)
        alloc = allocate(cands, bankroll=100_000_000, slots=8)
        kind, advice = alloc.binding_constraint
        self.assertIn(kind, {"slots", "capital", "market"})
        self.assertTrue(advice)


class PositionPnLTests(unittest.TestCase):
    def test_unrealised_marked_after_tax(self):
        pos = held(1, "X", 100, NOW, price=1_000)
        pnl = position_pnl(pos, 1_100)
        self.assertEqual(pnl.realised, 0)
        self.assertEqual(pnl.unrealised, (1_100 - sale_tax(1_100) - 1_000) * 100)

    def test_realised_is_tax_correct(self):
        pos = held(1, "X", 100, NOW, price=1_000, sold=100, sell=1_100)
        self.assertEqual(position_pnl(pos).realised, (1_100 - 22 - 1_000) * 100)

    def test_exempt_pays_no_tax(self):
        pos = held(1, "Old school bond", 100, NOW, price=1_000, sold=100,
                   sell=1_100, exempt=True)
        self.assertEqual(position_pnl(pos).realised, 100 * 100)

    def test_no_mark_means_no_invented_number(self):
        self.assertIsNone(position_pnl(held(1, "X", 100, NOW)).unrealised)

    def test_partial_sales_blend_by_weighted_average(self):
        pos = held(1, "X", 100, NOW, price=1_000)
        blend_sale(pos, 40, 1_100)
        blend_sale(pos, 60, 1_200)
        self.assertEqual(pos.sold_qty, 100)
        self.assertEqual(pos.sell_price, round((1_100 * 40 + 1_200 * 60) / 100))

    def test_cannot_oversell(self):
        pos = held(1, "X", 10, NOW)
        with self.assertRaises(ValueError):
            blend_sale(pos, 11, 100)
        with self.assertRaises(ValueError):
            blend_sale(pos, 0, 100)


class JournalPositionTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Path(self.tmp.name) / "j.sqlite3"

    def tearDown(self):
        self.tmp.cleanup()

    def test_round_trip(self):
        with Journal(self.db) as j:
            pid = j.add_position(1, "Teak plank", 13_000, 800)
            self.assertGreater(pid, 0)
            open_rows = j.positions(open_only=True)
            self.assertEqual(len(open_rows), 1)
            self.assertEqual(open_rows[0].name, "Teak plank")
            pos = j.record_sale(pid, 13_000, 825)
            self.assertEqual(pos.sold_qty, 13_000)
            self.assertEqual(j.positions(open_only=True), [])
            self.assertTrue(j.drop_position(pid))
            self.assertEqual(j.positions(), [])

    def test_partial_sale_persists(self):
        with Journal(self.db) as j:
            pid = j.add_position(1, "X", 100, 1_000)
            j.record_sale(pid, 40, 1_100)
            pos = j.positions()[0]
            self.assertEqual(pos.sold_qty, 40)
            self.assertEqual(pos.open_qty, 60)

    def test_rejects_bad_input(self):
        with Journal(self.db) as j:
            with self.assertRaises(ValueError):
                j.add_position(1, "X", 0, 100)
            with self.assertRaises(ValueError):
                j.add_position(1, "X", 10, 0)
            with self.assertRaises(ValueError):
                j.record_sale(999, 1, 100)

    def test_verification_deadlines(self):
        mapping = {1: meta(1, "X", limit=100)}
        latest = {1: quote(1, 1_000, 1_100)}
        hourly = {1: window(1, 1_000, 1_100)}
        cfg = ScanConfig(bankroll=10_000_000, min_daily_volume=0)
        cands = score_candidates(mapping, latest, hourly, {}, {}, cfg, now=NOW)
        with Journal(self.db) as j:
            j.record_scan(cands, cfg, None, now=NOW)
            fresh = j.verification_deadlines(now=NOW + 3600)
            self.assertEqual(fresh["expiring"], 0)
            soon = j.verification_deadlines(now=NOW + 24 * 3600)
            self.assertEqual(soon["expiring"], 1)
            gone = j.verification_deadlines(now=NOW + 40 * 3600)
            self.assertEqual(gone["expired"], 1)


# ===================== deeper model: shrinkage + history ====================

from osrsflip.scoring import apply_deep, deep_metrics  # noqa: E402


class VolumeShrinkageTests(unittest.TestCase):
    """A single hour is a noisy sample; sizing four hours off it is a mistake."""

    def setUp(self):
        self.mapping = {1: meta(1, "Thing", limit=1_000_000)}
        self.latest = {1: quote(1, 1_000, 1_100)}
        self.cfg = ScanConfig(bankroll=100_000_000, min_hourly_volume=0,
                              min_daily_volume=0, max_capital_fraction_per_item=1.0)

    def _one(self, hourly_vol, daily_vol=None):
        hourly = {1: window(1, 1_000, 1_100, low_vol=hourly_vol, high_vol=hourly_vol)}
        daily = ({1: window(1, 1_000, 1_100, low_vol=daily_vol, high_vol=daily_vol)}
                 if daily_vol is not None else {})
        return score_candidates(self.mapping, self.latest, hourly, daily, {},
                                self.cfg, now=NOW)[0]

    def test_quiet_hour_is_pulled_up_toward_the_daily_mean(self):
        c = self._one(100, 24_000)          # 100/h now, 1000/h typical
        self.assertAlmostEqual(c.activity, 0.1)
        self.assertAlmostEqual(c.flow_forecast, 550)
        self.assertEqual(c.quantity,
                         int(self.cfg.participation * 550 * self.cfg.cycle_hours))

    def test_spike_is_pulled_down(self):
        c = self._one(5_000, 24_000)
        self.assertAlmostEqual(c.activity, 5.0)
        self.assertAlmostEqual(c.flow_forecast, 3_000)
        self.assertLess(c.quantity,
                        int(self.cfg.participation * 5_000 * self.cfg.cycle_hours),
                        "the spike alone must not set the size")

    def test_no_daily_data_falls_back_without_inventing(self):
        c = self._one(500)
        self.assertIsNone(c.activity)
        self.assertAlmostEqual(c.flow_forecast, 500)

    def test_fill_times_follow_the_forecast(self):
        c = self._one(100, 24_000)
        self.assertAlmostEqual(
            c.fill_buy_minutes,
            (c.quantity / (550 * self.cfg.participation)) * 60)


class DeepMetricTests(unittest.TestCase):
    def setUp(self):
        mapping = {1: meta(1, "Thing", limit=100_000)}
        cfg = ScanConfig(bankroll=100_000_000, min_hourly_volume=0,
                         min_daily_volume=0, max_capital_fraction_per_item=1.0)
        self.cand = score_candidates(
            mapping, {1: quote(1, 1_000, 1_100)},
            {1: window(1, 1_000, 1_100, low_vol=500, high_vol=500)},
            {}, {}, cfg, now=NOW)[0]

    @staticmethod
    def _series(n, low, high):
        return [{"avgLowPrice": low, "avgHighPrice": high} for _ in range(n)]

    def test_steady_spread_scores_full_persistence(self):
        m = deep_metrics(self._series(48, 1_000, 1_100), self.cand)
        self.assertEqual(m.windows, 48)
        self.assertEqual(m.median_margin, net_margin(1_000, 1_100))
        self.assertEqual(m.persistence, 1.0)
        self.assertEqual(m.positive, 1.0)
        self.assertAlmostEqual(m.volatility, 0.0)

    def test_a_spread_that_just_appeared_scores_low(self):
        series = self._series(44, 1_100, 1_105) + self._series(4, 1_000, 1_100)
        m = deep_metrics(series, self.cand)
        self.assertLess(m.persistence, 0.15)

    def test_apply_deep_never_lets_the_snapshot_beat_history(self):
        series = self._series(44, 1_100, 1_105) + self._series(4, 1_000, 1_100)
        apply_deep(self.cand, deep_metrics(series, self.cand))
        self.assertLess(self.cand.deep_margin, self.cand.margin)
        self.assertLess(self.cand.deep_confidence, self.cand.confidence * 0.2)
        self.assertLess(self.cand.deep_gp_per_hour, self.cand.expected_gp_per_hour)

    def test_thin_history_returns_none_rather_than_guessing(self):
        self.assertIsNone(deep_metrics(self._series(4, 1_000, 1_100), self.cand))

    def test_apply_deep_is_a_noop_on_none(self):
        before = self.cand.expected_gp_per_hour
        apply_deep(self.cand, None)
        self.assertIsNone(self.cand.deep)
        self.assertEqual(self.cand.expected_gp_per_hour, before)

    def test_volatility_detected(self):
        series = [{"avgLowPrice": 1_000 + (300 if i % 2 else -300),
                   "avgHighPrice": 1_100 + (300 if i % 2 else -300)} for i in range(24)]
        self.assertGreater(deep_metrics(series, self.cand).volatility, 0.2)

    def test_nulls_in_history_are_skipped(self):
        series = ([{"avgLowPrice": None, "avgHighPrice": None}] * 10
                  + self._series(12, 1_000, 1_100))
        m = deep_metrics(series, self.cand)
        self.assertEqual(m.windows, 12)


class RoundingParityTests(unittest.TestCase):
    """Python rounds halves to even; JavaScript rounds them up. The two engines
    share this model and are diffed field-by-field, so .5 must not diverge."""

    def test_matches_javascript_math_round(self):
        from osrsflip.numeric import round_half_up
        for value, expected in [(0.5, 1), (1.5, 2), (2.5, 3), (76.5, 77),
                                (77.5, 78), (-0.5, 0), (0.4, 0), (0.6, 1)]:
            self.assertEqual(round_half_up(value), expected, value)

    def test_differs_from_builtin_round_where_it_matters(self):
        from osrsflip.numeric import round_half_up
        self.assertNotEqual(round_half_up(76.5), round(76.5))
        self.assertNotEqual(round_half_up(2.5), round(2.5))

    def test_blended_margin_uses_it(self):
        # instant 77 / hourly 76 averages to 76.5 and must land on 77, matching
        # the browser. This is the exact case the parity check caught.
        mapping = {1: meta(1, "X", limit=100_000)}
        cfg = ScanConfig(bankroll=100_000_000, min_hourly_volume=0,
                         min_daily_volume=0, max_capital_fraction_per_item=1.0)
        c = score_candidates(mapping, {1: quote(1, 1_000, 1_099)},
                             {1: window(1, 1_000, 1_098)}, {}, {}, cfg, now=NOW)[0]
        self.assertGreaterEqual(c.stability, 0.7)
        self.assertEqual(c.margin, math.floor(
            (c.instant_margin + c.hourly_margin) / 2 + 0.5))


class ObservedSlippageTests(unittest.TestCase):
    """Slippage is the gap between the price you see and the price you get.
    /latest gives the former, /5m the latter, so it can be measured."""

    def setUp(self):
        self.mapping = {1: meta(1, "A", limit=100_000)}
        self.cfg = ScanConfig(bankroll=10**9, min_hourly_volume=0,
                              min_daily_volume=0, max_capital_fraction_per_item=1.0)

    def _one(self, five):
        return score_candidates(
            self.mapping, {1: quote(1, 1_000, 1_100)},
            {1: window(1, 1_000, 1_100)}, {}, five, self.cfg, now=NOW)[0]

    def test_no_gap_means_no_slippage(self):
        self.assertAlmostEqual(self._one({1: window(1, 1_000, 1_100)}).slippage_observed, 0)

    def test_adverse_buy_side(self):
        c = self._one({1: window(1, 1_010, 1_100)})
        self.assertAlmostEqual(c.slippage_observed, (10 / 1_000) / 2)

    def test_adverse_sell_side(self):
        c = self._one({1: window(1, 1_000, 1_078)})
        self.assertAlmostEqual(c.slippage_observed, (22 / 1_100) / 2)

    def test_both_legs_add(self):
        c = self._one({1: window(1, 1_010, 1_078)})
        self.assertAlmostEqual(c.slippage_observed, ((10 / 1_000) + (22 / 1_100)) / 2)

    def test_favourable_moves_never_go_negative(self):
        """A quote that turned out generous is luck, not edge. It must not
        offset a genuine cost on the other leg."""
        c = self._one({1: window(1, 980, 1_130)})
        self.assertEqual(c.slippage_observed, 0)

    def test_missing_five_minute_data_is_none_not_zero(self):
        self.assertIsNone(self._one({}).slippage_observed)

    def test_market_read_refuses_small_samples(self):
        from osrsflip.scoring import observed_slippage
        cands = self._many(0.01, 500, 5)
        self.assertIsNone(observed_slippage(cands))

    def test_market_read_excludes_illiquid_noise(self):
        from osrsflip.scoring import observed_slippage
        cands = self._many(0.002, 500, 15) + self._many(0.09, 3, 40)
        result = observed_slippage(cands)
        self.assertAlmostEqual(result["median"], 0.002)
        self.assertEqual(result["n"], 15)

    def test_p75_at_or_above_median(self):
        from osrsflip.scoring import observed_slippage
        result = observed_slippage(self._many(0.001, 500, 10) + self._many(0.01, 500, 10))
        self.assertGreaterEqual(result["p75"], result["median"])

    def _many(self, slip, vol, count):
        base = score_candidates(
            self.mapping, {1: quote(1, 1_000, 1_100)},
            {1: window(1, 1_000, 1_100, low_vol=vol, high_vol=vol)},
            {}, {1: window(1, 1_000, 1_100)}, self.cfg, now=NOW)[0]
        out = []
        for _ in range(count):
            import copy
            c = copy.copy(base)
            c.slippage_observed = slip
            c.volume_1h = vol
            out.append(c)
        return out
