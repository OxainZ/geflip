"""HTTP client for the OSRS Wiki / RuneLite real-time Grand Exchange prices API.

Endpoints (base: https://prices.runescape.wiki/api/v1/<game>):
    /mapping                     static item metadata (name, buy limit, alch, members)
    /latest                      most recent insta-buy (high) / insta-sell (low) per item
    /5m , /1h , /24h             volume-weighted averages + traded volume per window
    /timeseries?timestep=&id=    historical windows for a single item

Design notes
------------
* Stdlib only. No third-party dependencies, so this drops into any environment.
* The wiki does not publish a hard rate limit but reserves the right to block
  abusive clients, and *requires* a descriptive User-Agent with contact info.
  We refuse to run without one rather than silently misbehaving on your behalf.
* /mapping is ~4k rows of near-static data, so it is cached to disk.
* Retries use exponential backoff with jitter and honour Retry-After.
"""

from __future__ import annotations

import gzip
import json
import logging
import random
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

log = logging.getLogger(__name__)

API_ROOT = "https://prices.runescape.wiki/api/v1"
VALID_GAMES = ("osrs", "dmm", "fsw")
VALID_TIMESTEPS = ("5m", "1h", "6h", "24h")

_PLACEHOLDER_AGENTS = {
    "",
    "python-urllib",
    "user-agent",
    "changeme",
    "your-user-agent",
}


class ApiError(RuntimeError):
    """Any non-recoverable failure talking to the prices API."""


class RateLimited(ApiError):
    """The API asked us to slow down and we exhausted our retries."""


@dataclass
class ClientConfig:
    #: Required. e.g. "flip-scanner - discord:oxainz" or an email address.
    user_agent: str
    game: str = "osrs"
    timeout: float = 20.0
    max_retries: int = 4
    backoff_base: float = 1.6
    #: Minimum wall-clock gap between outbound requests (politeness throttle).
    min_request_interval_s: float = 0.35
    cache_dir: Path | None = None
    mapping_ttl_s: int = 86_400

    def __post_init__(self) -> None:
        ua = (self.user_agent or "").strip()
        if ua.lower() in _PLACEHOLDER_AGENTS:
            raise ValueError(
                "A descriptive User-Agent is required by the OSRS Wiki API "
                "acceptable-use policy. Pass something like "
                "'osrs-flip-scanner - discord:yourname'."
            )
        if "@" not in ua and "discord" not in ua.lower() and "http" not in ua.lower():
            log.warning(
                "User-Agent %r contains no contact info. The wiki team asks for "
                "an email/Discord so they can reach you before blocking a tool.",
                ua,
            )
        self.user_agent = ua
        if self.game not in VALID_GAMES:
            raise ValueError(f"game must be one of {VALID_GAMES}, got {self.game!r}")
        if self.cache_dir is not None:
            self.cache_dir = Path(self.cache_dir)


@dataclass
class WikiPricesClient:
    config: ClientConfig
    _last_request_at: float = field(default=0.0, init=False, repr=False)

    # ---------------------------------------------------------------- internals

    def _throttle(self) -> None:
        gap = time.monotonic() - self._last_request_at
        wait = self.config.min_request_interval_s - gap
        if wait > 0:
            time.sleep(wait)
        self._last_request_at = time.monotonic()

    def _build_url(self, route: str, params: dict[str, Any] | None) -> str:
        url = f"{API_ROOT}/{self.config.game}/{route.lstrip('/')}"
        if params:
            clean = {k: v for k, v in params.items() if v is not None}
            if clean:
                url = f"{url}?{urllib.parse.urlencode(clean)}"
        return url

    def _get(self, route: str, params: dict[str, Any] | None = None) -> Any:
        url = self._build_url(route, params)
        last_exc: Exception | None = None

        for attempt in range(self.config.max_retries + 1):
            self._throttle()
            req = urllib.request.Request(
                url,
                headers={
                    "User-Agent": self.config.user_agent,
                    "Accept": "application/json",
                    "Accept-Encoding": "gzip",
                },
            )
            try:
                with urllib.request.urlopen(req, timeout=self.config.timeout) as resp:
                    raw = resp.read()
                    if resp.headers.get("Content-Encoding") == "gzip":
                        raw = gzip.decompress(raw)
                    return json.loads(raw.decode("utf-8"))

            except urllib.error.HTTPError as exc:
                last_exc = exc
                retry_after = exc.headers.get("Retry-After") if exc.headers else None
                if exc.code in (429, 500, 502, 503, 504):
                    delay = self._retry_delay(attempt, retry_after)
                    log.warning(
                        "HTTP %s from %s (attempt %d/%d); sleeping %.1fs",
                        exc.code, route, attempt + 1, self.config.max_retries + 1, delay,
                    )
                    time.sleep(delay)
                    continue
                raise ApiError(f"HTTP {exc.code} from {url}: {exc.reason}") from exc

            except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
                last_exc = exc
                delay = self._retry_delay(attempt, None)
                log.warning(
                    "Transport error on %s (attempt %d/%d): %s; sleeping %.1fs",
                    route, attempt + 1, self.config.max_retries + 1, exc, delay,
                )
                time.sleep(delay)

        if isinstance(last_exc, urllib.error.HTTPError) and last_exc.code == 429:
            raise RateLimited(f"Rate limited on {url} after retries") from last_exc
        raise ApiError(f"Failed to fetch {url} after retries: {last_exc}") from last_exc

    def _retry_delay(self, attempt: int, retry_after: str | None) -> float:
        if retry_after:
            try:
                return max(0.0, float(retry_after))
            except ValueError:
                pass
        return (self.config.backoff_base ** attempt) + random.uniform(0, 0.4)

    # ------------------------------------------------------------------- routes

    def mapping(self, *, use_cache: bool = True) -> list[dict[str, Any]]:
        """Static item metadata. Cached on disk because it barely changes."""
        cache_path = None
        if use_cache and self.config.cache_dir:
            self.config.cache_dir.mkdir(parents=True, exist_ok=True)
            cache_path = self.config.cache_dir / f"mapping-{self.config.game}.json"
            if cache_path.exists():
                age = time.time() - cache_path.stat().st_mtime
                if age < self.config.mapping_ttl_s:
                    try:
                        return json.loads(cache_path.read_text("utf-8"))
                    except (json.JSONDecodeError, OSError) as exc:
                        log.warning("Ignoring unreadable mapping cache: %s", exc)

        data = self._get("mapping")
        if not isinstance(data, list):
            raise ApiError("Unexpected /mapping payload: expected a list")

        if cache_path is not None:
            tmp = cache_path.with_suffix(".tmp")
            try:
                tmp.write_text(json.dumps(data), "utf-8")
                tmp.replace(cache_path)  # atomic; never leaves a half-written cache
            except OSError as exc:
                log.warning("Could not write mapping cache: %s", exc)
                tmp.unlink(missing_ok=True)
        return data

    def latest(self, item_id: int | None = None) -> dict[str, dict[str, Any]]:
        """Most recent high (insta-buy) / low (insta-sell) trade per item id."""
        payload = self._get("latest", {"id": item_id})
        return self._unwrap_data(payload, "latest")

    def window(self, timestep: str, timestamp: int | None = None) -> dict[str, dict[str, Any]]:
        """Aggregate prices/volumes for a 5m / 1h / 24h window."""
        if timestep not in VALID_TIMESTEPS:
            raise ValueError(f"timestep must be one of {VALID_TIMESTEPS}")
        payload = self._get(timestep, {"timestamp": timestamp})
        return self._unwrap_data(payload, timestep)

    def timeseries(self, item_id: int, timestep: str = "5m") -> list[dict[str, Any]]:
        """Up to 365 historical windows for one item, oldest first."""
        if timestep not in VALID_TIMESTEPS:
            raise ValueError(f"timestep must be one of {VALID_TIMESTEPS}")
        payload = self._get("timeseries", {"timestep": timestep, "id": item_id})
        data = payload.get("data") if isinstance(payload, dict) else None
        if not isinstance(data, list):
            raise ApiError(f"Unexpected /timeseries payload for item {item_id}")
        return data

    @staticmethod
    def _unwrap_data(payload: Any, route: str) -> dict[str, dict[str, Any]]:
        if not isinstance(payload, dict) or not isinstance(payload.get("data"), dict):
            raise ApiError(f"Unexpected /{route} payload: missing 'data' object")
        return payload["data"]
