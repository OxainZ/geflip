"""Display helpers: gp abbreviation, duration, and fixed-width tables."""

from __future__ import annotations

from typing import Iterable, Sequence

_SUFFIXES = (("b", 1_000_000_000), ("m", 1_000_000), ("k", 1_000))


def gp(value: float | int) -> str:
    """1_234_567 -> '1.23m'. Keeps three significant-ish digits."""
    sign = "-" if value < 0 else ""
    n = abs(float(value))
    for suffix, scale in _SUFFIXES:
        if n >= scale:
            scaled = n / scale
            digits = 2 if scaled < 10 else (1 if scaled < 100 else 0)
            return f"{sign}{scaled:.{digits}f}{suffix}"
    return f"{sign}{n:,.0f}"


def parse_gp(text: str) -> int:
    """Accepts '50m', '1.2b', '750k', '2,500' or plain digits."""
    s = str(text).strip().lower().replace(",", "").replace("_", "")
    if not s:
        raise ValueError("empty amount")
    multiplier = 1
    for suffix, scale in _SUFFIXES:
        if s.endswith(suffix):
            multiplier = scale
            s = s[: -len(suffix)]
            break
    try:
        value = float(s)
    except ValueError as exc:
        raise ValueError(f"could not parse gp amount: {text!r}") from exc
    if value < 0:
        raise ValueError(f"gp amount must be non-negative: {text!r}")
    return int(value * multiplier)


def duration(seconds: float) -> str:
    seconds = max(0.0, float(seconds))
    if seconds < 60:
        return f"{seconds:.0f}s"
    if seconds < 3600:
        return f"{seconds / 60:.0f}m"
    if seconds < 86_400:
        return f"{seconds / 3600:.1f}h"
    return f"{seconds / 86_400:.1f}d"


def pct(value: float, digits: int = 2) -> str:
    return f"{value * 100:.{digits}f}%"


def table(headers: Sequence[str], rows: Iterable[Sequence[object]]) -> str:
    """Left-align text columns, right-align anything numeric-looking."""
    body = [[str(cell) for cell in row] for row in rows]
    if not body:
        return "  (no rows)"

    widths = [len(h) for h in headers]
    for row in body:
        for i, cell in enumerate(row):
            if i < len(widths):
                widths[i] = max(widths[i], len(cell))

    right = [
        all(_looks_numeric(row[i]) for row in body if i < len(row))
        for i in range(len(headers))
    ]

    def render(cells: Sequence[str]) -> str:
        parts = []
        for i, cell in enumerate(cells):
            parts.append(cell.rjust(widths[i]) if right[i] else cell.ljust(widths[i]))
        return "  ".join(parts).rstrip()

    lines = [render(headers), render(["-" * w for w in widths])]
    lines.extend(render(row) for row in body)
    return "\n".join(lines)


def _looks_numeric(cell: str) -> bool:
    stripped = cell.strip().lstrip("-").rstrip("%bkm")
    stripped = stripped.replace(",", "").replace(".", "", 1)
    return stripped.isdigit() or cell.strip() in {"-", ""}
