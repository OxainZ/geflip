"""Pre-registration journal and forward verification.

A flip scanner that only ever shows you today's list is unfalsifiable. This
module writes every recommendation to SQLite at the moment it is made, then
later replays the item's own price history to ask whether the quoted prices were
actually reachable.

What ``verify`` measures, precisely
-----------------------------------
For each recommendation it pulls the 5-minute timeseries covering
``[recommended_at, recommended_at + horizon]`` and asks:

  buy_filled   - did any window print an average insta-sell at or below our
                 intended buy price? (i.e. could a buy offer there have filled)
  sell_filled  - after the buy window, did any window print an average insta-buy
                 at or above our intended sell price?
  realized     - net margin using the best sell actually printed after our buy,
                 which is the optimistic bound on what the flip could return.

What it does NOT measure: queue position, partial fills, or competition from
other flippers reading the same public feed. Treat ``realized`` as a ceiling.
If your live results sit well below it, the gap is your true slippage, and
that number belongs in ``ScanConfig.slippage``.
"""

from __future__ import annotations

import json
import math
import sqlite3
import statistics
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any, Callable, Iterable, Sequence

from .allocate import Allocation
from .book import Position, blend_sale
from .scoring import Candidate, ScanConfig
from .tax import net_margin

SCHEMA_VERSION = 1

_SCHEMA = """
PRAGMA journal_mode=WAL;

CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS scans (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at      REAL    NOT NULL,
    game            TEXT    NOT NULL,
    config_json     TEXT    NOT NULL,
    candidate_count INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS recommendations (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    scan_id          INTEGER NOT NULL REFERENCES scans(id) ON DELETE CASCADE,
    recommended_at   REAL    NOT NULL,
    item_id          INTEGER NOT NULL,
    name             TEXT    NOT NULL,
    buy_price        INTEGER NOT NULL,
    sell_price       INTEGER NOT NULL,
    margin           INTEGER NOT NULL,
    roi              REAL    NOT NULL,
    quantity         INTEGER NOT NULL,
    capital          INTEGER NOT NULL,
    expected_gph     REAL    NOT NULL,
    confidence       REAL    NOT NULL,
    volume_1h        INTEGER NOT NULL,
    quote_age_s      REAL    NOT NULL,
    limiting_factor  TEXT    NOT NULL,
    tax_exempt       INTEGER NOT NULL DEFAULT 0,
    allocated        INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS outcomes (
    rec_id          INTEGER PRIMARY KEY REFERENCES recommendations(id) ON DELETE CASCADE,
    checked_at      REAL    NOT NULL,
    horizon_hours   REAL    NOT NULL,
    buy_filled      INTEGER NOT NULL,
    sell_filled     INTEGER NOT NULL,
    best_sell       INTEGER,
    realized_margin INTEGER,
    windows_seen    INTEGER NOT NULL,
    note            TEXT
);

CREATE TABLE IF NOT EXISTS positions (
    pid         INTEGER PRIMARY KEY AUTOINCREMENT,
    item_id     INTEGER NOT NULL,
    name        TEXT    NOT NULL,
    qty         INTEGER NOT NULL,
    buy_price   INTEGER NOT NULL,
    bought_at   REAL    NOT NULL,
    sold_qty    INTEGER NOT NULL DEFAULT 0,
    sell_price  INTEGER,
    sold_at     REAL,
    tax_exempt  INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_pos_item ON positions(item_id, bought_at);
CREATE INDEX IF NOT EXISTS idx_rec_scan ON recommendations(scan_id);
CREATE INDEX IF NOT EXISTS idx_rec_item_time ON recommendations(item_id, recommended_at);
CREATE INDEX IF NOT EXISTS idx_rec_allocated ON recommendations(allocated);
"""


class Journal:
    """Thin, explicit SQLite wrapper. One connection, used as a context manager."""

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(str(self.path))
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys=ON")
        self.conn.executescript(_SCHEMA)
        self.conn.execute(
            "INSERT OR IGNORE INTO meta(key, value) VALUES ('schema_version', ?)",
            (str(SCHEMA_VERSION),),
        )
        self.conn.commit()

    def __enter__(self) -> "Journal":
        return self

    def __exit__(self, *exc_info: object) -> None:
        self.close()

    def close(self) -> None:
        try:
            self.conn.commit()
        finally:
            self.conn.close()

    # ------------------------------------------------------------------ writes

    def record_scan(
        self,
        candidates: Sequence[Candidate],
        config: ScanConfig,
        allocation: Allocation | None = None,
        *,
        game: str = "osrs",
        top_n: int = 25,
        now: float | None = None,
    ) -> int:
        """Persist a scan and its top picks. Returns the scan id."""
        ts = time.time() if now is None else now
        allocated_ids = (
            {p.candidate.item_id for p in allocation.positions} if allocation else set()
        )
        allocated_qty = (
            {p.candidate.item_id: (p.quantity, p.capital) for p in allocation.positions}
            if allocation
            else {}
        )

        cur = self.conn.execute(
            "INSERT INTO scans(created_at, game, config_json, candidate_count) "
            "VALUES (?, ?, ?, ?)",
            (ts, game, json.dumps(asdict(config), sort_keys=True), len(candidates)),
        )
        scan_id = int(cur.lastrowid)

        # Always journal the allocated picks, even if they fall outside top_n.
        recorded: dict[int, Candidate] = {c.item_id: c for c in candidates[:top_n]}
        for cand in candidates:
            if cand.item_id in allocated_ids:
                recorded.setdefault(cand.item_id, cand)

        rows = []
        for cand in recorded.values():
            qty, capital = allocated_qty.get(
                cand.item_id, (cand.quantity, cand.capital_required)
            )
            rows.append(
                (
                    scan_id, ts, cand.item_id, cand.name, cand.buy_price, cand.sell_price,
                    cand.margin, cand.roi, qty, capital, cand.expected_gp_per_hour,
                    cand.confidence, cand.volume_1h, cand.quote_age_s,
                    cand.limiting_factor, int(cand.tax_exempt),
                    int(cand.item_id in allocated_ids),
                )
            )

        self.conn.executemany(
            "INSERT INTO recommendations("
            " scan_id, recommended_at, item_id, name, buy_price, sell_price, margin,"
            " roi, quantity, capital, expected_gph, confidence, volume_1h, quote_age_s,"
            " limiting_factor, tax_exempt, allocated"
            ") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            rows,
        )
        self.conn.commit()
        return scan_id

    # -------------------------------------------------------------- positions

    def add_position(
        self, item_id: int, name: str, qty: int, buy_price: int,
        *, tax_exempt: bool = False, bought_at: float | None = None,
    ) -> int:
        if qty <= 0:
            raise ValueError("quantity must be positive")
        if buy_price <= 0:
            raise ValueError("buy price must be positive")
        ts = time.time() if bought_at is None else bought_at
        cur = self.conn.execute(
            "INSERT INTO positions(item_id, name, qty, buy_price, bought_at, tax_exempt) "
            "VALUES (?,?,?,?,?,?)",
            (item_id, name, qty, buy_price, ts, int(tax_exempt)),
        )
        self.conn.commit()
        return int(cur.lastrowid)

    def positions(self, *, open_only: bool = False) -> list[Position]:
        rows = self.conn.execute(
            "SELECT * FROM positions ORDER BY bought_at DESC"
        ).fetchall()
        out = [
            Position(
                pid=r["pid"], item_id=r["item_id"], name=r["name"], qty=r["qty"],
                buy_price=r["buy_price"], bought_at=r["bought_at"],
                sold_qty=r["sold_qty"], sell_price=r["sell_price"],
                sold_at=r["sold_at"], tax_exempt=bool(r["tax_exempt"]),
            )
            for r in rows
        ]
        return [p for p in out if p.is_open] if open_only else out

    def record_sale(self, pid: int, qty: int, price: int) -> Position:
        """Fold a sale into the position, blending partials by weighted average."""
        row = self.conn.execute(
            "SELECT * FROM positions WHERE pid = ?", (pid,)
        ).fetchone()
        if row is None:
            raise ValueError(f"no position {pid}")
        pos = Position(
            pid=row["pid"], item_id=row["item_id"], name=row["name"], qty=row["qty"],
            buy_price=row["buy_price"], bought_at=row["bought_at"],
            sold_qty=row["sold_qty"], sell_price=row["sell_price"],
            sold_at=row["sold_at"], tax_exempt=bool(row["tax_exempt"]),
        )
        blend_sale(pos, qty, price)
        pos.sold_at = time.time()
        self.conn.execute(
            "UPDATE positions SET sold_qty=?, sell_price=?, sold_at=? WHERE pid=?",
            (pos.sold_qty, pos.sell_price, pos.sold_at, pid),
        )
        self.conn.commit()
        return pos

    def drop_position(self, pid: int) -> bool:
        cur = self.conn.execute("DELETE FROM positions WHERE pid = ?", (pid,))
        self.conn.commit()
        return cur.rowcount > 0

    # ------------------------------------------------------------ verification

    def pending_verification(
        self, horizon_hours: float, *, now: float | None = None, limit: int = 200
    ) -> list[sqlite3.Row]:
        ts = time.time() if now is None else now
        cutoff = ts - horizon_hours * 3600.0
        return list(
            self.conn.execute(
                "SELECT r.* FROM recommendations r "
                "LEFT JOIN outcomes o ON o.rec_id = r.id "
                "WHERE o.rec_id IS NULL AND r.recommended_at <= ? "
                "ORDER BY r.recommended_at ASC LIMIT ?",
                (cutoff, limit),
            )
        )

    def verify(
        self,
        fetch_timeseries: Callable[[int, str], Iterable[dict[str, Any]]],
        *,
        horizon_hours: float = 8.0,
        now: float | None = None,
        limit: int = 200,
        timestep: str = "5m",
    ) -> dict[str, int]:
        """Replay price history for matured recommendations and store outcomes."""
        ts = time.time() if now is None else now
        pending = self.pending_verification(horizon_hours, now=ts, limit=limit)
        if not pending:
            return {"checked": 0, "filled": 0, "no_data": 0}

        by_item: dict[int, list[sqlite3.Row]] = {}
        for row in pending:
            by_item.setdefault(int(row["item_id"]), []).append(row)

        checked = filled = no_data = 0
        for item_id, recs in by_item.items():
            try:
                series = list(fetch_timeseries(item_id, timestep))
            except Exception as exc:  # noqa: BLE001 - one bad item must not abort the run
                for row in recs:
                    self._store_outcome(
                        row["id"], ts, horizon_hours, False, False, None, None, 0,
                        f"timeseries error: {exc}",
                    )
                    no_data += 1
                continue

            for row in recs:
                start = float(row["recommended_at"])
                end = start + horizon_hours * 3600.0
                window = [
                    w for w in series
                    if w.get("timestamp") is not None and start <= float(w["timestamp"]) <= end
                ]
                if not window:
                    self._store_outcome(
                        row["id"], ts, horizon_hours, False, False, None, None, 0,
                        "no windows in horizon",
                    )
                    no_data += 1
                    continue

                buy_price = int(row["buy_price"])
                sell_price = int(row["sell_price"])

                buy_idx = next(
                    (
                        i for i, w in enumerate(window)
                        if w.get("avgLowPrice") is not None
                        and int(w["avgLowPrice"]) <= buy_price
                    ),
                    None,
                )
                buy_filled = buy_idx is not None

                best_sell: int | None = None
                if buy_filled:
                    after = window[buy_idx:]
                    highs = [
                        int(w["avgHighPrice"])
                        for w in after
                        if w.get("avgHighPrice") is not None
                    ]
                    best_sell = max(highs) if highs else None

                sell_filled = bool(best_sell is not None and best_sell >= sell_price)
                realized = (
                    net_margin(buy_price, best_sell, exempt=bool(row["tax_exempt"]))
                    if best_sell is not None
                    else None
                )

                self._store_outcome(
                    row["id"], ts, horizon_hours, buy_filled, sell_filled,
                    best_sell, realized, len(window), None,
                )
                checked += 1
                if buy_filled and sell_filled:
                    filled += 1

        self.conn.commit()
        return {"checked": checked, "filled": filled, "no_data": no_data}

    def _store_outcome(
        self, rec_id: int, checked_at: float, horizon: float, buy_filled: bool,
        sell_filled: bool, best_sell: int | None, realized: int | None,
        windows: int, note: str | None,
    ) -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO outcomes("
            " rec_id, checked_at, horizon_hours, buy_filled, sell_filled,"
            " best_sell, realized_margin, windows_seen, note"
            ") VALUES (?,?,?,?,?,?,?,?,?)",
            (rec_id, checked_at, horizon, int(buy_filled), int(sell_filled),
             best_sell, realized, windows, note),
        )

    # ------------------------------------------------------------------- stats

    def stats(self, *, allocated_only: bool = False) -> dict[str, Any]:
        """Predicted vs realized, plus a naive t-stat on realized ROI.

        The t-stat assumes independent observations, which is false: the same
        item recommended in consecutive scans is one bet, not two, and market-wide
        moves correlate everything. Read it as a smoke alarm, not a p-value.
        """
        where = "WHERE r.allocated = 1" if allocated_only else ""
        rows = list(
            self.conn.execute(
                f"SELECT r.margin, r.roi, r.buy_price, r.quantity, r.confidence, "
                f"o.buy_filled, o.sell_filled, o.realized_margin "
                f"FROM recommendations r JOIN outcomes o ON o.rec_id = r.id {where}"
            )
        )
        if not rows:
            return {"observations": 0}

        n = len(rows)
        both = [r for r in rows if r["buy_filled"] and r["sell_filled"]]
        realized_rois = [
            r["realized_margin"] / r["buy_price"]
            for r in rows
            if r["realized_margin"] is not None and r["buy_price"] > 0
        ]
        predicted_rois = [r["roi"] for r in rows]

        out: dict[str, Any] = {
            "observations": n,
            "buy_fill_rate": sum(bool(r["buy_filled"]) for r in rows) / n,
            "round_trip_rate": len(both) / n,
            "mean_predicted_roi": statistics.fmean(predicted_rois),
        }
        if realized_rois:
            mean = statistics.fmean(realized_rois)
            out["mean_realized_roi"] = mean
            out["realized_minus_predicted_roi"] = mean - out["mean_predicted_roi"]
            if len(realized_rois) > 1:
                sd = statistics.stdev(realized_rois)
                out["t_stat_naive"] = (
                    mean / (sd / math.sqrt(len(realized_rois))) if sd > 0 else float("inf")
                )
            realized_gp = [
                r["realized_margin"] * r["quantity"]
                for r in rows
                if r["realized_margin"] is not None
            ]
            out["total_realized_gp_if_all_filled"] = sum(realized_gp)
        return out

    def verification_deadlines(self, *, now: float | None = None) -> dict[str, int]:
        """Picks approaching or past the 5m history horizon.

        /timeseries returns at most 365 points, so the 5-minute series only
        reaches back about 30 hours. Past that a recommendation can never be
        graded, and the calibration data is lost for good.
        """
        ts = time.time() if now is None else now
        rows = self.conn.execute(
            "SELECT r.recommended_at FROM recommendations r "
            "LEFT JOIN outcomes o ON o.rec_id = r.id WHERE o.rec_id IS NULL"
        ).fetchall()
        expiring = sum(1 for r in rows if 22 * 3600 < ts - r[0] < 30 * 3600)
        expired = sum(1 for r in rows if ts - r[0] >= 30 * 3600)
        return {"expiring": expiring, "expired": expired, "pending": len(rows)}

    def recent_scans(self, limit: int = 10) -> list[sqlite3.Row]:
        return list(
            self.conn.execute(
                "SELECT s.*, COUNT(r.id) AS recs FROM scans s "
                "LEFT JOIN recommendations r ON r.scan_id = s.id "
                "GROUP BY s.id ORDER BY s.created_at DESC LIMIT ?",
                (limit,),
            )
        )
