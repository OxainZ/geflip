"""Ranking engine.

The ranking key is **expected gp per hour**, not margin percent. A 40% margin on
an item with a buy limit of 6 is worth less than a 1% margin on one you can move
10,000 of, and every list that sorts by ROI buries the second kind.

Four things degrade a raw quoted spread, and all four are modelled explicitly:

1. Tax          - 2% off the sell side, so the quoted spread overstates profit.
2. Buy limits   - you can only buy N units per 4h, per account, per item.
3. Throughput   - you cannot sell more than the market absorbs, whatever the limit.
4. Trust        - /latest is last-traded, not an order book. A wide spread on a
                  stale, thin, or one-off print is not an opportunity.

(1)-(3) shrink the quantity and the per-unit profit. (4) becomes a confidence
multiplier in [0, 1] rather than a hard filter, so you can see marginal items and
judge them yourself instead of having them silently dropped.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Mapping, Sequence

from .book import LimitState
from .models import EMPTY_WINDOW, ItemMeta, LatestQuote, WindowStat
from .tax import breakeven_sell_price, net_margin, sale_tax

NATURE_RUNE_ID = 561


def tick_size(price: int) -> int:
    """Smallest price step worth paying to jump the offer queue.

    The GE matches better prices first, and among equal prices the OLDER offer
    wins. So a tick is not overpaying — it is what buys priority over everyone
    already sitting at the same price.
    """
    return max(1, int(price * 0.0005 + 0.5))


@dataclass(slots=True)
class ScanConfig:
    """Every knob, with defaults chosen to be conservative rather than flattering."""

    bankroll: int = 50_000_000
    slots: int = 8
    members: bool = True

    # --- hard gates -------------------------------------------------------
    min_hourly_volume: int = 20          # two-sided units traded in the last hour
    min_daily_volume: int = 500          # two-sided units traded in the last 24h
    max_quote_age_s: float = 3_600.0     # drop quotes older than this outright
    min_margin_gp: int = 1
    min_roi: float = 0.0                 # net margin / buy price
    min_unit_price: int = 1
    max_unit_price: int | None = None
    #: Buy limit to assume when /mapping has none. None means skip the item.
    unknown_limit_default: int | None = None

    # --- realism adjustments ---------------------------------------------
    #: Adverse price move applied to BOTH sides, as a fraction. 0.005 means you
    #: assume you must bid 0.5% above the quoted low and ask 0.5% below the high
    #: to actually get filled. Zero is the optimistic case; calibrate it from
    #: your own journal rather than trusting the default.
    slippage: float = 0.0
    #: You cannot absorb the whole market. Fraction of observed volume you assume
    #: you can capture on the binding side.
    participation: float = 0.10
    #: Fraction of bankroll any single item may consume in the standalone estimate.
    max_capital_fraction_per_item: float = 0.25
    cycle_hours: float = 4.0             # GE buy limits reset on a rolling 4h window
    #: Penalty applied when the price is sliding fast inside the hour: a wide
    #: spread on a collapsing item is not a flip, it is a falling knife.
    falling_knife_threshold: float = -0.03
    falling_knife_penalty: float = 0.8

    # --- confidence shaping ----------------------------------------------
    staleness_tau_s: float = 1_200.0     # freshness decays e-fold per 20 minutes
    volume_saturation: int = 200         # hourly volume at which volume confidence = 1
    #: Multiplier applied when there is no hourly window to corroborate the spread.
    unverified_haircut: float = 0.5

    def __post_init__(self) -> None:
        if self.bankroll < 0:
            raise ValueError("bankroll must be non-negative")
        if self.slots < 1:
            raise ValueError("slots must be at least 1")
        if not 0.0 <= self.slippage < 0.5:
            raise ValueError("slippage must be in [0, 0.5)")
        if not 0.0 < self.participation <= 1.0:
            raise ValueError("participation must be in (0, 1]")
        if not 0.0 < self.max_capital_fraction_per_item <= 1.0:
            raise ValueError("max_capital_fraction_per_item must be in (0, 1]")
        if self.cycle_hours <= 0:
            raise ValueError("cycle_hours must be positive")
        if self.staleness_tau_s <= 0:
            raise ValueError("staleness_tau_s must be positive")
        if self.volume_saturation < 1:
            raise ValueError("volume_saturation must be at least 1")
        if not 0.0 <= self.unverified_haircut <= 1.0:
            raise ValueError("unverified_haircut must be in [0, 1]")


@dataclass(slots=True)
class Candidate:
    item_id: int
    name: str
    members: bool
    tax_exempt: bool
    buy_price: int
    sell_price: int
    tax_per_unit: int
    margin: int                  # conservative net margin per unit, after tax
    instant_margin: int          # margin implied by /latest alone
    hourly_margin: int | None    # margin implied by the 1h VWAP, if available
    roi: float
    buy_limit: int
    throughput_cap: int          # units the market can absorb at our participation rate
    quantity: int                # units per cycle after limit/capital/throughput
    capital_required: int
    cycle_profit: int
    gp_per_hour: float           # unweighted
    expected_gp_per_hour: float  # gp_per_hour * confidence
    confidence: float
    freshness: float
    volume_score: float
    stability: float
    quote_age_s: float
    volume_1h: int
    volume_24h: int
    volume_5m: int
    breakeven_sell: int
    alch_cushion: float | None   # (high alch - nature rune) / buy price, if known
    limiting_factor: str         # which of limit/capital/throughput bound quantity

    # --- capital efficiency: what this returns per gp tied up, not per position
    roi_per_hour: float
    gp_per_million: float

    # --- where to actually place the offers
    bid_competitive: int
    ask_competitive: int
    margin_competitive: int
    margin_check_cost: int

    # --- order flow: which leg is the bottleneck
    sellers_per_hour: int        # people insta-selling; fills your BUY
    buyers_per_hour: int         # people insta-buying; fills your SELL
    fill_buy_minutes: float
    fill_sell_minutes: float
    bottleneck: str
    flow_skew: float             # +1 all sellers, -1 all buyers

    # --- drift
    trend_1h: float | None
    trend_24h: float | None
    activity: float | None       # this hour's volume vs the day's mean hour
    flow_forecast: float         # shrunk volume estimate used for sizing

    # --- buy limit state
    limit_total: int | None
    limit_reset_at: float | None
    limit_shared: bool

    # --- populated only by the optional deep pass
    deep: "DeepMetrics | None" = None
    deep_margin: int = 0
    deep_confidence: float = 0.0
    deep_gp_per_hour: float = 0.0

    def as_record(self) -> dict[str, Any]:
        return {
            "item_id": self.item_id,
            "name": self.name,
            "buy_price": self.buy_price,
            "sell_price": self.sell_price,
            "margin": self.margin,
            "roi": self.roi,
            "quantity": self.quantity,
            "capital_required": self.capital_required,
            "cycle_profit": self.cycle_profit,
            "expected_gp_per_hour": self.expected_gp_per_hour,
            "confidence": self.confidence,
            "volume_1h": self.volume_1h,
            "volume_24h": self.volume_24h,
            "quote_age_s": self.quote_age_s,
            "limiting_factor": self.limiting_factor,
        }


@dataclass(slots=True)
class RejectionLog:
    """Counts of why items were dropped. Surfaces over-tight filters immediately."""

    counts: dict[str, int] = field(default_factory=dict)

    def add(self, reason: str) -> None:
        self.counts[reason] = self.counts.get(reason, 0) + 1

    def summary(self, limit: int = 12) -> list[tuple[str, int]]:
        return sorted(self.counts.items(), key=lambda kv: -kv[1])[:limit]


def _apply_slippage(buy: int, sell: int, slippage: float) -> tuple[int, int]:
    """Move both sides against us. Buy rounds up, sell rounds down."""
    if slippage <= 0:
        return buy, sell
    adj_buy = math.ceil(buy * (1.0 + slippage))
    adj_sell = math.floor(sell * (1.0 - slippage))
    return adj_buy, adj_sell


def _stability(instant: int, hourly: int | None, unverified_haircut: float) -> float:
    """How far the instantaneous spread disagrees with the hourly VWAP spread.

    A huge instant margin against a near-zero hourly margin is the signature of
    one outlier print, which is the single most common way a flip list lies.
    """
    if hourly is None:
        return unverified_haircut
    scale = max(abs(instant), abs(hourly), 1)
    return max(0.0, 1.0 - abs(instant - hourly) / scale)


def score_candidates(
    mapping: Mapping[int, ItemMeta],
    latest: Mapping[int, LatestQuote],
    hourly: Mapping[int, WindowStat] | None = None,
    daily: Mapping[int, WindowStat] | None = None,
    five_min: Mapping[int, WindowStat] | None = None,
    config: ScanConfig | None = None,
    *,
    now: float,
    rejections: RejectionLog | None = None,
    limits: Mapping[int, LimitState] | None = None,
) -> list[Candidate]:
    """Score every tradeable item and return survivors, best expected gp/h first."""
    cfg = config or ScanConfig()
    hourly = hourly or {}
    daily = daily or {}
    five_min = five_min or {}
    rej = rejections if rejections is not None else RejectionLog()

    nature_quote = latest.get(NATURE_RUNE_ID)
    nature_price = nature_quote.high if nature_quote and nature_quote.high else None

    per_item_capital = int(cfg.bankroll * cfg.max_capital_fraction_per_item)
    out: list[Candidate] = []

    for item_id, quote in latest.items():
        meta = mapping.get(item_id)
        if meta is None:
            rej.add("no mapping entry")
            continue
        if meta.members and not cfg.members:
            rej.add("members item on f2p account")
            continue
        if not quote.two_sided:
            rej.add("missing a price side")
            continue

        age = quote.staleness_s(now)
        if age is None:
            rej.add("missing a trade timestamp")
            continue
        if age > cfg.max_quote_age_s:
            rej.add("quote too stale")
            continue

        buy, sell = _apply_slippage(int(quote.low), int(quote.high), cfg.slippage)
        if buy < cfg.min_unit_price:
            rej.add("below min unit price")
            continue
        if cfg.max_unit_price is not None and buy > cfg.max_unit_price:
            rej.add("above max unit price")
            continue

        instant_margin = net_margin(buy, sell, exempt=meta.tax_exempt)

        h1 = hourly.get(item_id, EMPTY_WINDOW)
        d24 = daily.get(item_id, EMPTY_WINDOW)
        m5 = five_min.get(item_id, EMPTY_WINDOW)

        hourly_margin: int | None = None
        if h1.avg_high is not None and h1.avg_low is not None:
            h_buy, h_sell = _apply_slippage(h1.avg_low, h1.avg_high, cfg.slippage)
            hourly_margin = net_margin(h_buy, h_sell, exempt=meta.tax_exempt)

        # Take the pessimistic view when the two disagree. This is the single
        # most important line in the file: it is what stops one lucky print from
        # topping the list.
        if hourly_margin is None:
            margin = int(instant_margin * cfg.unverified_haircut)
        else:
            margin = min(instant_margin, hourly_margin)

        if margin < cfg.min_margin_gp:
            rej.add("margin below floor")
            continue

        roi = margin / buy if buy > 0 else 0.0
        if roi < cfg.min_roi:
            rej.add("roi below floor")
            continue

        vol_1h = h1.two_sided_volume
        if vol_1h < cfg.min_hourly_volume:
            rej.add("hourly volume too thin")
            continue
        vol_24h = d24.two_sided_volume
        if daily and vol_24h < cfg.min_daily_volume:
            rej.add("daily volume too thin")
            continue

        # Shrinkage estimator. A single hour is a noisy sample: a 3am lull and a
        # post-update spike are both poor predictors of the next four hours, so
        # blend this hour with the day's mean hour.
        hourly_24 = vol_24h / 24 if vol_24h > 0 else None
        flow_forecast = (vol_1h + hourly_24) / 2 if hourly_24 is not None else float(vol_1h)
        activity = vol_1h / hourly_24 if hourly_24 else None

        limit = meta.buy_limit
        if limit is None:
            if cfg.unknown_limit_default is None:
                rej.add("unknown buy limit")
                continue
            limit = cfg.unknown_limit_default
        if limit <= 0:
            rej.add("zero buy limit")
            continue

        # Whatever you already bought this window is gone until it resets, and
        # dose variants draw on the same allowance.
        limit_total = limit
        limit_reset_at: float | None = None
        limit_shared = False
        state = (limits or {}).get(item_id)
        if state is not None and state.is_open:
            limit_reset_at = state.reset_at
            limit_shared = state.shared
            limit = min(limit, state.remaining)
            if limit <= 0:
                rej.add("buy limit already spent")
                continue

        affordable = per_item_capital // buy if buy > 0 else 0
        throughput = int(cfg.participation * flow_forecast * cfg.cycle_hours)
        quantity = min(limit, affordable, throughput)
        if quantity <= 0:
            rej.add("no affordable/absorbable quantity")
            continue

        binding = min(
            (limit, "buy limit"),
            (affordable, "capital"),
            (throughput, "market throughput"),
            key=lambda pair: pair[0],
        )[1]

        capital_required = quantity * buy
        cycle_profit = margin * quantity
        gp_per_hour = cycle_profit / cfg.cycle_hours

        # --- order flow -------------------------------------------------
        # low volume  = people INSTA-SELLING, the flow that fills your BUY.
        # high volume = people INSTA-BUYING, the flow that fills your SELL.
        sellers_hr = h1.low_volume
        buyers_hr = h1.high_volume
        # Same shrinkage on each leg so fill times track the forecast.
        shrink = flow_forecast / vol_1h if (hourly_24 is not None and vol_1h > 0) else 1.0
        sellers_fc, buyers_fc = sellers_hr * shrink, buyers_hr * shrink
        fill_buy = (
            (quantity / (sellers_fc * cfg.participation)) * 60
            if sellers_fc > 0 else math.inf
        )
        fill_sell = (
            (quantity / (buyers_fc * cfg.participation)) * 60
            if buyers_fc > 0 else math.inf
        )
        bottleneck = "sell" if fill_sell > fill_buy else "buy"
        total_flow = sellers_hr + buyers_hr
        flow_skew = (sellers_hr - buyers_hr) / total_flow if total_flow else 0.0

        # --- drift ------------------------------------------------------
        mid_now = (buy + sell) / 2
        mid_1h = (
            (h1.avg_low + h1.avg_high) / 2
            if h1.avg_low is not None and h1.avg_high is not None else None
        )
        mid_24h = (
            (d24.avg_low + d24.avg_high) / 2
            if d24.avg_low is not None and d24.avg_high is not None else None
        )
        trend_1h = (mid_now - mid_1h) / mid_1h if mid_1h else None
        trend_24h = (mid_now - mid_24h) / mid_24h if mid_24h else None
        knife = (
            cfg.falling_knife_penalty
            if trend_1h is not None and trend_1h < cfg.falling_knife_threshold
            else 1.0
        )

        # --- offer prices -----------------------------------------------
        tick_buy, tick_sell = tick_size(buy), tick_size(sell)
        bid_comp = buy + tick_buy
        ask_comp = max(bid_comp + 1, sell - tick_sell)
        haircut_delta = instant_margin - margin      # keep the pessimism
        margin_comp = (
            net_margin(bid_comp, ask_comp, exempt=meta.tax_exempt) - haircut_delta
        )
        # Cost of verifying the spread in game: buy 1 at the ask, dump 1 at the bid.
        check_cost = (
            int(quote.high) - int(quote.low)
            + sale_tax(int(quote.low), exempt=meta.tax_exempt)
        )

        freshness = math.exp(-age / cfg.staleness_tau_s)
        volume_score = min(1.0, vol_1h / cfg.volume_saturation) ** 0.5
        stability = _stability(instant_margin, hourly_margin, cfg.unverified_haircut)
        confidence = max(0.0, min(1.0, freshness * volume_score * stability * knife))

        alch_cushion: float | None = None
        if meta.high_alch and nature_price and buy > 0:
            alch_cushion = (meta.high_alch - nature_price - buy) / buy

        out.append(
            Candidate(
                item_id=item_id,
                name=meta.name,
                members=meta.members,
                tax_exempt=meta.tax_exempt,
                buy_price=buy,
                sell_price=sell,
                tax_per_unit=sale_tax(sell, exempt=meta.tax_exempt),
                margin=margin,
                instant_margin=instant_margin,
                hourly_margin=hourly_margin,
                roi=roi,
                buy_limit=limit,
                throughput_cap=throughput,
                quantity=quantity,
                capital_required=capital_required,
                cycle_profit=cycle_profit,
                gp_per_hour=gp_per_hour,
                expected_gp_per_hour=gp_per_hour * confidence,
                confidence=confidence,
                freshness=freshness,
                volume_score=volume_score,
                stability=stability,
                quote_age_s=age,
                volume_1h=vol_1h,
                volume_24h=vol_24h,
                volume_5m=m5.two_sided_volume,
                breakeven_sell=breakeven_sell_price(buy, exempt=meta.tax_exempt),
                alch_cushion=alch_cushion,
                limiting_factor=binding,
                roi_per_hour=(roi / cfg.cycle_hours) * confidence,
                gp_per_million=(roi / cfg.cycle_hours) * confidence * 1_000_000,
                bid_competitive=bid_comp,
                ask_competitive=ask_comp,
                margin_competitive=margin_comp,
                margin_check_cost=check_cost,
                sellers_per_hour=sellers_hr,
                buyers_per_hour=buyers_hr,
                fill_buy_minutes=fill_buy,
                fill_sell_minutes=fill_sell,
                bottleneck=bottleneck,
                flow_skew=flow_skew,
                trend_1h=trend_1h,
                trend_24h=trend_24h,
                activity=activity,
                flow_forecast=flow_forecast,
                limit_total=limit_total,
                limit_reset_at=limit_reset_at,
                limit_shared=limit_shared,
            )
        )

    out.sort(key=lambda c: (-c.expected_gp_per_hour, -c.confidence, c.name))
    return out


@dataclass(slots=True)
class DeepMetrics:
    """What the last N hours say about a spread the snapshot only saw once."""

    windows: int
    median_margin: int
    persistence: float   # share of hours where >= half of today's margin existed
    positive: float      # share of hours with any margin at all
    volatility: float    # stdev of the mid price over its mean


def deep_metrics(
    series: Sequence[Mapping[str, Any]], candidate: Candidate, hours: int = 48
) -> DeepMetrics | None:
    """Measure how durable a candidate's margin has actually been.

    The fast scan compares one instant against one hour, which cannot separate a
    spread that has held all day from one that opened ninety seconds ago.
    """
    window = [
        w for w in series[-hours:]
        if w.get("avgHighPrice") is not None and w.get("avgLowPrice") is not None
    ]
    if len(window) < 6:
        return None

    margins = [
        net_margin(int(w["avgLowPrice"]), int(w["avgHighPrice"]),
                   exempt=candidate.tax_exempt)
        for w in window
    ]
    mids = [(int(w["avgLowPrice"]) + int(w["avgHighPrice"])) / 2 for w in window]
    ordered = sorted(margins)
    median = ordered[len(ordered) // 2]
    persistence = (
        sum(1 for m in margins if m >= candidate.margin * 0.5) / len(margins)
        if candidate.margin > 0 else 0.0
    )
    mean = sum(mids) / len(mids)
    variance = sum((m - mean) ** 2 for m in mids) / len(mids)
    return DeepMetrics(
        windows=len(window),
        median_margin=median,
        persistence=persistence,
        positive=sum(1 for m in margins if m > 0) / len(margins),
        volatility=(variance ** 0.5) / mean if mean > 0 else 0.0,
    )


def apply_deep(candidate: Candidate, metrics: DeepMetrics | None,
               cycle_hours: float = 4.0) -> Candidate:
    """Fold history into the candidate. The snapshot never beats the record."""
    if metrics is None:
        return candidate
    candidate.deep = metrics
    candidate.deep_margin = max(0, min(candidate.margin, metrics.median_margin))
    candidate.deep_confidence = max(
        0.0, min(1.0, candidate.confidence * metrics.persistence)
    )
    candidate.deep_gp_per_hour = (
        candidate.deep_margin * candidate.quantity / cycle_hours
    ) * candidate.deep_confidence
    return candidate


def summarise(candidates: Sequence[Candidate]) -> dict[str, Any]:
    if not candidates:
        return {"count": 0}
    return {
        "count": len(candidates),
        "median_confidence": sorted(c.confidence for c in candidates)[len(candidates) // 2],
        "best_expected_gph": candidates[0].expected_gp_per_hour,
        "total_expected_gph_top8": sum(c.expected_gp_per_hour for c in candidates[:8]),
    }
