"""Command line interface.

    python -m osrsflip scan   --bankroll 50m --slots 8
    python -m osrsflip verify --horizon 8
    python -m osrsflip stats
    python -m osrsflip item "Abyssal whip"
    python -m osrsflip scans

Set OSRS_FLIP_UA to a descriptive User-Agent with contact info, e.g.
    export OSRS_FLIP_UA="osrs-flip-scanner - discord:yourname"
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
import time
from dataclasses import asdict
from pathlib import Path

from . import fmt
from .allocate import Allocation, allocate
from .api import ApiError, ClientConfig, WikiPricesClient
from .book import limit_map, position_pnl, rolling_reset_schedule
from .journal import Journal
from .models import parse_latest, parse_mapping, parse_window
from .scoring import Candidate, RejectionLog, ScanConfig, score_candidates

DEFAULT_DB = Path.home() / ".osrsflip" / "journal.sqlite3"
DEFAULT_CACHE = Path.home() / ".osrsflip" / "cache"
UA_ENV = "OSRS_FLIP_UA"

log = logging.getLogger("osrsflip")


# --------------------------------------------------------------------- helpers


def _client(args: argparse.Namespace) -> WikiPricesClient:
    ua = args.user_agent or os.environ.get(UA_ENV, "")
    if not ua.strip():
        raise SystemExit(
            f"No User-Agent set. The OSRS Wiki API requires one.\n"
            f'  export {UA_ENV}="osrs-flip-scanner - discord:yourname"\n'
            f"  ...or pass --user-agent."
        )
    return WikiPricesClient(
        ClientConfig(
            user_agent=ua,
            game=args.game,
            cache_dir=Path(args.cache_dir),
            timeout=args.timeout,
        )
    )


def _scan_config(args: argparse.Namespace) -> ScanConfig:
    return ScanConfig(
        bankroll=fmt.parse_gp(args.bankroll),
        slots=args.slots,
        members=not args.f2p,
        min_hourly_volume=args.min_volume,
        min_daily_volume=args.min_daily_volume,
        max_quote_age_s=args.max_age,
        min_margin_gp=fmt.parse_gp(args.min_margin),
        min_roi=args.min_roi,
        min_unit_price=fmt.parse_gp(args.min_price),
        max_unit_price=fmt.parse_gp(args.max_price) if args.max_price else None,
        unknown_limit_default=args.unknown_limit,
        slippage=args.slippage,
        participation=args.participation,
        max_capital_fraction_per_item=args.max_item_fraction,
    )


def _fill_txt(minutes: float) -> str:
    if minutes == float("inf"):
        return "never"
    if minutes < 1:
        return "<1m"
    if minutes < 90:
        return f"{minutes:.0f}m"
    return f"{minutes / 60:.1f}h"


def _trend_txt(value: float | None) -> str:
    if value is None:
        return "-"
    return f"{value * 100:+.1f}%"


def _print_candidates(candidates: list[Candidate], top: int) -> None:
    rows = []
    for c in candidates[:top]:
        rows.append(
            [
                c.name[:26],
                fmt.gp(c.buy_price),
                fmt.gp(c.margin),
                fmt.pct(c.roi, 2),
                f"{c.quantity:,}",
                fmt.gp(c.capital_required),
                fmt.gp(c.expected_gp_per_hour),
                fmt.pct(c.roi_per_hour, 2),
                f"{c.confidence:.2f}",
                _fill_txt(max(c.fill_buy_minutes, c.fill_sell_minutes)),
                _trend_txt(c.trend_1h),
                c.limiting_factor,
            ]
        )
    print(
        fmt.table(
            ["item", "buy", "margin", "roi", "qty", "capital",
             "gp/h", "%/h", "conf", "fill", "1h", "bound by"],
            rows,
        )
    )


def _print_offers(candidates: list[Candidate], count: int) -> None:
    """Exact prices to post. The GE fills better prices first and breaks ties in
    favour of the older offer, so a tick is what buys queue priority."""
    print("\nWhere to place your offers  (competitive = one tick inside the spread)")
    rows = []
    for c in candidates[:count]:
        rows.append([
            c.name[:26],
            f"{c.buy_price:,} / {c.sell_price:,}",
            f"{c.bid_competitive:,} / {c.ask_competitive:,}",
            fmt.gp(c.margin_competitive),
            f"{c.sellers_per_hour:,} / {c.buyers_per_hour:,}",
            c.bottleneck,
            fmt.gp(c.margin_check_cost),
        ])
    print(fmt.table(
        ["item", "patient buy/sell", "competitive buy/sell", "margin",
         "sellers/buyers per h", "slower leg", "check cost"], rows))


def _print_allocation(alloc: Allocation) -> None:
    print("\nSuggested slot allocation")
    rows = []
    for pos in alloc.positions:
        c = pos.candidate
        rows.append(
            [
                c.name[:28],
                f"{pos.quantity:,}",
                fmt.gp(c.buy_price),
                fmt.gp(c.sell_price),
                fmt.gp(pos.capital),
                fmt.gp(pos.cycle_profit),
                fmt.gp(pos.expected_gp_per_hour),
                f"{c.confidence:.2f}",
            ]
        )
    print(
        fmt.table(
            ["item", "qty", "buy @", "sell @", "capital", "profit/cycle",
             "exp gp/h", "conf"],
            rows,
        )
    )
    constraint, advice = alloc.binding_constraint
    print(
        f"\n  slots used        {alloc.slots_used}/{alloc.slots}\n"
        f"  capital deployed  {fmt.gp(alloc.capital_deployed)} "
        f"({fmt.pct(alloc.capital_deployed / alloc.bankroll if alloc.bankroll else 0, 1)})\n"
        f"  capital idle      {fmt.gp(alloc.capital_idle)}\n"
        f"  expected/4h cycle {fmt.gp(alloc.expected_cycle_profit)}"
        f"  ({fmt.pct(alloc.return_on_deployed, 2)} on deployed)\n"
        f"  expected gp/hour  {fmt.gp(alloc.expected_gp_per_hour)}\n"
        f"  per 1m deployed   {fmt.gp(alloc.gp_per_million_deployed)}/h\n"
        f"\n  Binding constraint: {constraint.upper()}. {advice}"
    )


# -------------------------------------------------------------------- commands


def cmd_scan(args: argparse.Namespace) -> int:
    client = _client(args)
    cfg = _scan_config(args)
    started = time.time()

    log.info("fetching item mapping...")
    mapping = parse_mapping(client.mapping())
    log.info("fetching latest quotes...")
    latest = parse_latest(client.latest())
    log.info("fetching 1h window...")
    hourly = parse_window(client.window("1h"))
    five_min = parse_window(client.window("5m")) if not args.fast else {}
    daily = parse_window(client.window("24h")) if not args.fast else {}

    now = time.time()
    with Journal(args.db) as journal:
        held = journal.positions(open_only=False)
    limits = limit_map(held, mapping, now)

    rejections = RejectionLog()
    candidates = score_candidates(
        mapping, latest, hourly, daily, five_min,
        cfg, now=now, rejections=rejections, limits=limits,
    )

    if args.json:
        payload = {
            "generated_at": started,
            "config": asdict(cfg),
            "candidates": [c.as_record() for c in candidates[: args.top]],
        }
        alloc = allocate(candidates, bankroll=cfg.bankroll, slots=cfg.slots,
                         max_item_fraction=cfg.max_capital_fraction_per_item)
        payload["allocation"] = {
            "expected_gp_per_hour": alloc.expected_gp_per_hour,
            "capital_deployed": alloc.capital_deployed,
            "positions": [
                {"item_id": p.candidate.item_id, "name": p.candidate.name,
                 "quantity": p.quantity, "buy": p.candidate.buy_price,
                 "sell": p.candidate.sell_price, "capital": p.capital}
                for p in alloc.positions
            ],
        }
        print(json.dumps(payload, indent=2))
        return 0

    print(
        f"\nScanned {len(latest):,} priced items -> {len(candidates):,} candidates "
        f"in {time.time() - started:.1f}s  "
        f"(bankroll {fmt.gp(cfg.bankroll)}, {cfg.slots} slots, "
        f"{'members' if cfg.members else 'f2p'})"
    )
    if cfg.slippage == 0:
        print(
            "  note: slippage is 0, so margins assume you get filled at the last "
            "traded prices. Run `verify` for a few days, then set --slippage from "
            "the realized gap."
        )
    print()

    if not candidates:
        print("No candidates survived the filters.")
        _print_rejections(rejections)
        return 1

    _print_candidates(candidates, args.top)

    alloc = allocate(candidates, bankroll=cfg.bankroll, slots=cfg.slots,
                     max_item_fraction=cfg.max_capital_fraction_per_item)
    _print_allocation(alloc)

    if args.offers:
        _print_offers(candidates, min(args.top, 10))

    if args.explain:
        _print_rejections(rejections)

    if not args.no_journal:
        with Journal(args.db) as journal:
            scan_id = journal.record_scan(
                candidates, cfg, alloc, game=args.game, top_n=args.top, now=started
            )
        print(f"\nJournalled as scan #{scan_id} in {args.db}")
    return 0


def _print_rejections(rejections: RejectionLog) -> None:
    print("\nWhy items were dropped")
    print(fmt.table(["reason", "items"],
                    [[r, f"{n:,}"] for r, n in rejections.summary()]))


def _resolve_item(client: WikiPricesClient, needle: str):
    mapping = parse_mapping(client.mapping())
    hits = [m for m in mapping.values() if needle.strip().lower() in m.name.lower()]
    if not hits:
        raise SystemExit(f"No item matching {needle!r}")
    hits.sort(key=lambda m: (len(m.name), m.name))
    return mapping, hits[0]


def cmd_buy(args: argparse.Namespace) -> int:
    client = _client(args)
    mapping, meta = _resolve_item(client, args.item)
    with Journal(args.db) as journal:
        pid = journal.add_position(
            meta.item_id, meta.name, args.quantity, fmt.parse_gp(args.price),
            tax_exempt=meta.tax_exempt,
        )
        held = journal.positions()
    state = limit_map(held, mapping, time.time()).get(meta.item_id)
    print(f"Logged #{pid}: {args.quantity:,} x {meta.name} @ {fmt.parse_gp(args.price):,}")
    if state and state.is_open:
        left = "unlimited" if state.remaining >= 2**30 else f"{state.remaining:,}"
        print(f"  buy limit {state.spent:,} used, {left} left, "
              f"resets in {fmt.duration(state.reset_at - time.time())}")
        if state.shared:
            print("  note: dose variants share this allowance")
    return 0


def cmd_sell(args: argparse.Namespace) -> int:
    with Journal(args.db) as journal:
        pos = journal.record_sale(args.pid, args.quantity, fmt.parse_gp(args.price))
        pnl = position_pnl(pos)
    print(f"Position #{pos.pid} {pos.name}: sold {args.quantity:,} @ "
          f"{fmt.parse_gp(args.price):,}")
    print(f"  realised {fmt.gp(pnl.realised)} after tax, {pnl.open_qty:,} still held")
    return 0


def cmd_book(args: argparse.Namespace) -> int:
    with Journal(args.db) as journal:
        held = journal.positions()
    if not held:
        print("Nothing in the book. Use `buy` after an offer fills.")
        return 1

    marks: dict[int, int] = {}
    if not args.offline:
        try:
            client = _client(args)
            latest = parse_latest(client.latest())
            marks = {i: q.high for i, q in latest.items() if q.high is not None}
        except (ApiError, SystemExit):
            print("  (no live prices; showing realised only)\n")

    rows, realised_total, unrealised_total, at_risk = [], 0, 0, 0
    for pos in held:
        pnl = position_pnl(pos, marks.get(pos.item_id))
        realised_total += pnl.realised
        unrealised_total += pnl.unrealised or 0
        at_risk += pos.buy_price * pos.open_qty
        total = pnl.total
        rows.append([
            pos.pid,
            "holding" if pos.is_open else "closed",
            pos.name[:24],
            f"{pos.open_qty:,}" if pos.is_open else f"{pos.qty:,}",
            f"{pos.buy_price:,}",
            f"{pos.sell_price:,}" if pos.sell_price else "-",
            f"{'+' if total >= 0 else ''}{fmt.gp(total)}",
        ])
    print(fmt.table(["#", "state", "item", "qty", "buy", "sell", "p&l"], rows))
    print(f"\n  gp at risk   {fmt.gp(at_risk)}\n"
          f"  realised     {'+' if realised_total >= 0 else ''}{fmt.gp(realised_total)}\n"
          f"  unrealised   {'+' if unrealised_total >= 0 else ''}{fmt.gp(unrealised_total)}")
    return 0


def cmd_limits(args: argparse.Namespace) -> int:
    client = _client(args)
    mapping = parse_mapping(client.mapping())
    now = time.time()
    with Journal(args.db) as journal:
        held = journal.positions()
    schedule = rolling_reset_schedule(held, mapping, now)
    if not schedule:
        print("No buy limits in use.")
        return 1
    rows = []
    for label, state in schedule:
        left = "unlimited" if state.remaining >= 2**30 else f"{state.remaining:,}"
        rows.append([label[:34], f"{state.spent:,}", left,
                     fmt.duration((state.reset_at or now) - now),
                     "shared" if state.shared else ""])
    print(fmt.table(["item", "used", "left", "resets in", ""], rows))
    print("\n  The window opens on your FIRST buy and resets exactly 4h later,"
          "\n  however late the rest fills — so buy as much as you can early."
          "\n  Selling is never limited, only buying.")
    return 0


def cmd_verify(args: argparse.Namespace) -> int:
    client = _client(args)
    with Journal(args.db) as journal:
        result = journal.verify(
            lambda item_id, step: client.timeseries(item_id, step),
            horizon_hours=args.horizon,
            limit=args.limit,
        )
    print(
        f"Verified {result['checked']} recommendation(s); "
        f"{result['filled']} completed a round trip; "
        f"{result['no_data']} had no usable history."
    )
    with Journal(args.db) as journal:
        deadlines = journal.verification_deadlines()
    if deadlines["expiring"]:
        print(f"\n  {deadlines['expiring']} pick(s) expiring: 5m history only reaches "
              f"back ~30h, so verify them now or they can never be graded.")
    if deadlines["expired"]:
        print(f"  {deadlines['expired']} pick(s) are already too old to grade.")
    return 0


def cmd_stats(args: argparse.Namespace) -> int:
    with Journal(args.db) as journal:
        stats = journal.stats(allocated_only=args.allocated_only)
    if stats.get("observations", 0) == 0:
        print("No verified recommendations yet. Run `scan`, wait, then `verify`.")
        return 1

    print("\nJournal performance"
          + (" (allocated picks only)" if args.allocated_only else ""))
    rows = []
    for key, value in stats.items():
        if isinstance(value, float):
            shown = fmt.pct(value) if "roi" in key or "rate" in key else f"{value:,.3f}"
        else:
            shown = f"{value:,}"
        rows.append([key.replace("_", " "), shown])
    print(fmt.table(["metric", "value"], rows))
    print(
        "\n  Realized ROI is an upper bound: it assumes you were first in the "
        "queue at both ends.\n  The gap between predicted and realized is your "
        "slippage estimate."
    )
    return 0


def cmd_item(args: argparse.Namespace) -> int:
    client = _client(args)
    mapping = parse_mapping(client.mapping())
    needle = args.name.strip().lower()
    matches = [m for m in mapping.values() if needle in m.name.lower()]
    if not matches:
        print(f"No item matching {args.name!r}")
        return 1
    matches.sort(key=lambda m: (len(m.name), m.name))
    meta = matches[0]

    latest = parse_latest(client.latest(item_id=meta.item_id))
    quote = latest.get(meta.item_id)
    series = client.timeseries(meta.item_id, args.timestep)[-args.points :]

    print(f"\n{meta.name}  (id {meta.item_id})")
    print(f"  buy limit {meta.buy_limit if meta.buy_limit is not None else 'unknown'}"
          f"   high alch {meta.high_alch or '-'}"
          f"   {'members' if meta.members else 'f2p'}"
          f"   {'TAX EXEMPT' if meta.tax_exempt else ''}")
    if quote and quote.two_sided:
        from .tax import net_margin  # local import keeps module import graph flat
        margin = net_margin(int(quote.low), int(quote.high), exempt=meta.tax_exempt)
        print(f"  latest: buy {fmt.gp(quote.low)} / sell {fmt.gp(quote.high)} "
              f"-> net margin {fmt.gp(margin)}")

    rows = []
    for w in series:
        rows.append([
            time.strftime("%m-%d %H:%M", time.localtime(w["timestamp"])),
            fmt.gp(w["avgLowPrice"]) if w.get("avgLowPrice") else "-",
            fmt.gp(w["avgHighPrice"]) if w.get("avgHighPrice") else "-",
            f"{w.get('lowPriceVolume', 0):,}",
            f"{w.get('highPriceVolume', 0):,}",
        ])
    print()
    print(fmt.table(["window", "avg buy", "avg sell", "sold vol", "bought vol"], rows))
    if len(matches) > 1:
        others = ", ".join(m.name for m in matches[1:6])
        print(f"\n  also matched: {others}")
    return 0


def cmd_scans(args: argparse.Namespace) -> int:
    with Journal(args.db) as journal:
        rows = journal.recent_scans(args.limit)
    if not rows:
        print("No scans journalled yet.")
        return 1
    print(fmt.table(
        ["id", "when", "game", "candidates", "logged"],
        [[r["id"],
          time.strftime("%Y-%m-%d %H:%M", time.localtime(r["created_at"])),
          r["game"], f"{r['candidate_count']:,}", r["recs"]] for r in rows],
    ))
    return 0


# ---------------------------------------------------------------------- parser


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="osrsflip",
        description="Rank Grand Exchange flips by expected gp/hour, tax and buy "
                    "limits included, and journal the picks so you can falsify them.",
    )
    p.add_argument("--user-agent", default=None,
                   help=f"Descriptive UA with contact info (or set ${UA_ENV})")
    p.add_argument("--game", default="osrs", choices=("osrs", "dmm", "fsw"))
    p.add_argument("--db", default=str(DEFAULT_DB), help="journal SQLite path")
    p.add_argument("--cache-dir", default=str(DEFAULT_CACHE))
    p.add_argument("--timeout", type=float, default=20.0)
    p.add_argument("-v", "--verbose", action="store_true")

    sub = p.add_subparsers(dest="command", required=True)

    s = sub.add_parser("scan", help="rank flips right now")
    s.add_argument("--bankroll", default="50m", help="e.g. 50m, 1.2b, 750k")
    s.add_argument("--slots", type=int, default=8, help="8 for members, 3 for f2p")
    s.add_argument("--f2p", action="store_true", help="exclude members-only items")
    s.add_argument("--top", type=int, default=25)
    s.add_argument("--min-volume", type=int, default=20,
                   help="min two-sided units traded in the last hour")
    s.add_argument("--min-daily-volume", type=int, default=500)
    s.add_argument("--max-age", type=float, default=3600.0,
                   help="drop quotes older than this many seconds")
    s.add_argument("--min-margin", default="1", help="min net gp per unit")
    s.add_argument("--min-roi", type=float, default=0.0)
    s.add_argument("--min-price", default="1")
    s.add_argument("--max-price", default=None)
    s.add_argument("--unknown-limit", type=int, default=None,
                   help="assume this buy limit when the API has none (default: skip)")
    s.add_argument("--slippage", type=float, default=0.0,
                   help="adverse fraction applied to both sides, e.g. 0.005")
    s.add_argument("--participation", type=float, default=0.10,
                   help="fraction of observed volume you assume you can capture")
    s.add_argument("--max-item-fraction", type=float, default=0.25,
                   help="cap on how much of the bank any one item may consume")
    s.add_argument("--offers", action="store_true",
                   help="print the exact buy/sell prices to post")
    s.add_argument("--fast", action="store_true",
                   help="skip the 5m and 24h fetches (fewer liquidity checks)")
    s.add_argument("--json", action="store_true")
    s.add_argument("--explain", action="store_true", help="show filter rejection counts")
    s.add_argument("--no-journal", action="store_true")
    s.set_defaults(func=cmd_scan)

    v = sub.add_parser("verify", help="replay history against past recommendations")
    v.add_argument("--horizon", type=float, default=8.0,
                   help="hours a flip is given to complete")
    v.add_argument("--limit", type=int, default=200)
    v.set_defaults(func=cmd_verify)

    st = sub.add_parser("stats", help="predicted vs realized from the journal")
    st.add_argument("--allocated-only", action="store_true")
    st.set_defaults(func=cmd_stats)

    it = sub.add_parser("item", help="inspect one item")
    it.add_argument("name")
    it.add_argument("--timestep", default="1h", choices=("5m", "1h", "6h", "24h"))
    it.add_argument("--points", type=int, default=24)
    it.set_defaults(func=cmd_item)

    b = sub.add_parser("buy", help="log a filled buy offer")
    b.add_argument("item")
    b.add_argument("quantity", type=int)
    b.add_argument("price")
    b.set_defaults(func=cmd_buy)

    sl = sub.add_parser("sell", help="log a filled sell offer")
    sl.add_argument("pid", type=int, help="position number from `book`")
    sl.add_argument("quantity", type=int)
    sl.add_argument("price")
    sl.set_defaults(func=cmd_sell)

    bk = sub.add_parser("book", help="open positions and realised p&l")
    bk.add_argument("--offline", action="store_true", help="skip live marks")
    bk.set_defaults(func=cmd_book)

    lm = sub.add_parser("limits", help="buy limit timers, soonest reset first")
    lm.set_defaults(func=cmd_limits)

    sc = sub.add_parser("scans", help="list journalled scans")
    sc.add_argument("--limit", type=int, default=10)
    sc.set_defaults(func=cmd_scans)

    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    logging.basicConfig(
        level=logging.INFO if args.verbose else logging.WARNING,
        format="%(levelname)s %(message)s",
    )
    try:
        return int(args.func(args))
    except ApiError as exc:
        print(f"API error: {exc}", file=sys.stderr)
        return 2
    except (ValueError, OSError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        print("\nInterrupted.", file=sys.stderr)
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
