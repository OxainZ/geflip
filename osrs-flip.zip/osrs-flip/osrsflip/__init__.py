"""osrsflip - Grand Exchange flip scanner with tax-correct, liquidity-aware ranking."""

from .allocate import Allocation, Position, allocate
from .book import (
    LIMIT_WINDOW_S, LimitState, PnL, blend_sale, limit_for, limit_group,
    limit_map, position_pnl, rolling_reset_schedule,
)
from .book import Position as HeldPosition
from .api import ApiError, ClientConfig, RateLimited, WikiPricesClient
from .journal import Journal
from .numeric import round_half_up
from .models import ItemMeta, LatestQuote, WindowStat, parse_latest, parse_mapping, parse_window
from .scoring import Candidate, RejectionLog, ScanConfig, score_candidates, tick_size
from .tax import breakeven_sell_price, net_margin, net_proceeds, sale_tax

__version__ = "2.0.0"

__all__ = [
    "Allocation", "Position", "allocate",
    "LIMIT_WINDOW_S", "LimitState", "PnL", "HeldPosition", "blend_sale",
    "limit_for", "limit_group", "limit_map", "position_pnl", "rolling_reset_schedule",
    "ApiError", "ClientConfig", "RateLimited", "WikiPricesClient",
    "Journal",
    "ItemMeta", "LatestQuote", "WindowStat",
    "parse_latest", "parse_mapping", "parse_window",
    "Candidate", "RejectionLog", "ScanConfig", "score_candidates", "tick_size",
    "round_half_up",
    "breakeven_sell_price", "net_margin", "net_proceeds", "sale_tax",
    "__version__",
]
