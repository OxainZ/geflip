"""Shared arithmetic conventions.

Kept as a leaf module (imports nothing from the package) so both the scoring
engine and the position book can use it without a circular import.
"""

from __future__ import annotations

import math


def round_half_up(value: float) -> int:
    """Match JavaScript's ``Math.round``.

    Python rounds halves to even — ``round(76.5) == 76``, ``round(77.5) == 78``
    — while JavaScript rounds them up unconditionally. The browser build and
    this one share the same model and are checked field-by-field against each
    other, so any shared arithmetic that can land on .5 must agree to the coin.
    The browser's convention wins because that is where most people run it.
    """
    return math.floor(value + 0.5)
