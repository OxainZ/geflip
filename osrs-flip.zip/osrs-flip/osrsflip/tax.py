"""Grand Exchange sale tax.

Current rules (verified against the OSRS Wiki, July 2026):

* 2% of the sale price, deducted from the SELLER only. Buyers pay list price.
  The rate was 1% from 9 Dec 2021 and rose to 2% on 29 May 2025.
* Rounded DOWN to the nearest coin, per item, so anything selling under 50 gp
  pays nothing at all (floor(49 * 0.02) == 0).
* Capped at 5,000,000 gp PER ITEM, not per offer. Selling 10 units at 300M each
  costs 50M in tax, not 5M.
* A short list of items is fully exempt: bonds plus a handful of starter tools.

The exemption list is deliberately overridable. Jagex has changed it before and
a stale hardcoded set would silently mis-price those items, so treat the default
below as a starting point and refresh it from the wiki if you trade tools.
"""

from __future__ import annotations

GE_TAX_NUMERATOR = 2
GE_TAX_DENOMINATOR = 100
GE_TAX_CAP = 5_000_000

#: Price at or above which any tax is owed at all, given floor rounding.
GE_TAX_FREE_CEILING = GE_TAX_DENOMINATOR // GE_TAX_NUMERATOR  # 50

#: Sale price at which the 5M cap starts binding.
GE_TAX_CAP_THRESHOLD = GE_TAX_CAP * GE_TAX_DENOMINATOR // GE_TAX_NUMERATOR  # 250M

DEFAULT_EXEMPT_ITEM_NAMES: frozenset[str] = frozenset(
    {
        "old school bond",
        "chisel",
        "gardening trowel",
        "glassblowing pipe",
        "hammer",
        "needle",
        "pestle and mortar",
        "rake",
        "saw",
        "secateurs",
        "seed dibber",
        "shears",
        "spade",
        "watering can",
    }
)


def sale_tax(sell_price: int, *, exempt: bool = False) -> int:
    """Tax owed on selling ONE unit at ``sell_price``.

    Uses exact integer arithmetic: float multiplication by 0.02 misrounds on
    large prices (e.g. a 1.79B twisted bow) and those errors compound across a
    whole-market scan.
    """
    if sell_price < 0:
        raise ValueError(f"sell_price must be non-negative, got {sell_price}")
    if exempt or sell_price < GE_TAX_FREE_CEILING:
        return 0
    return min(sell_price * GE_TAX_NUMERATOR // GE_TAX_DENOMINATOR, GE_TAX_CAP)


def net_proceeds(sell_price: int, *, exempt: bool = False) -> int:
    """Coins actually received per unit sold."""
    return sell_price - sale_tax(sell_price, exempt=exempt)


def net_margin(buy_price: int, sell_price: int, *, exempt: bool = False) -> int:
    """Profit per unit on a completed round trip. Can be negative."""
    return net_proceeds(sell_price, exempt=exempt) - buy_price


def breakeven_sell_price(buy_price: int, *, exempt: bool = False) -> int:
    """Lowest whole-coin sell price where the flip does not lose money.

    Solved by inversion then corrected by search, because floor rounding and the
    5M cap make the closed form wrong near the boundaries.
    """
    if buy_price < 0:
        raise ValueError(f"buy_price must be non-negative, got {buy_price}")
    if exempt:
        return buy_price

    if buy_price >= GE_TAX_CAP_THRESHOLD - GE_TAX_CAP:
        guess = buy_price + GE_TAX_CAP
    else:
        guess = -(-buy_price * GE_TAX_DENOMINATOR //
                  (GE_TAX_DENOMINATOR - GE_TAX_NUMERATOR))  # ceil division

    guess = max(0, guess - 2)
    while net_proceeds(guess, exempt=exempt) < buy_price:
        guess += 1
    return guess


def is_exempt(item_name: str, exempt_names: frozenset[str] | None = None) -> bool:
    names = DEFAULT_EXEMPT_ITEM_NAMES if exempt_names is None else exempt_names
    return item_name.strip().lower() in names
