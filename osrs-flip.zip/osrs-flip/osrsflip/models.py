"""Typed views over the raw API payloads.

Everything the API returns is loosely typed JSON with plenty of nulls: items
that have never traded, windows with one-sided volume, mapping rows missing a
buy limit. Parsing is centralised here so the scoring code can assume clean
inputs and never has to guard against a stray None mid-formula.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable

from .tax import DEFAULT_EXEMPT_ITEM_NAMES


def _as_int(value: Any) -> int | None:
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    if isinstance(value, str):
        try:
            return int(value.strip())
        except ValueError:
            return None
    return None


@dataclass(frozen=True, slots=True)
class ItemMeta:
    item_id: int
    name: str
    members: bool
    buy_limit: int | None
    high_alch: int | None
    low_alch: int | None
    ge_value: int | None
    tax_exempt: bool

    @classmethod
    def from_mapping_row(
        cls, row: dict[str, Any], exempt_names: frozenset[str] = DEFAULT_EXEMPT_ITEM_NAMES
    ) -> "ItemMeta | None":
        item_id = _as_int(row.get("id"))
        name = row.get("name")
        if item_id is None or not isinstance(name, str) or not name:
            return None
        return cls(
            item_id=item_id,
            name=name,
            members=bool(row.get("members", False)),
            buy_limit=_as_int(row.get("limit")),
            high_alch=_as_int(row.get("highalch")),
            low_alch=_as_int(row.get("lowalch")),
            ge_value=_as_int(row.get("value")),
            tax_exempt=name.strip().lower() in exempt_names,
        )


@dataclass(frozen=True, slots=True)
class LatestQuote:
    """Last observed trade on each side.

    ``high`` is the most recent insta-BUY price (someone lifted the ask), so it
    approximates where you can SELL. ``low`` is the most recent insta-SELL, so
    it approximates where you can BUY. This is not an order book: there is no
    depth behind either number and both can be stale.
    """

    item_id: int
    high: int | None
    high_time: int | None
    low: int | None
    low_time: int | None

    @classmethod
    def from_payload(cls, item_id: int, row: dict[str, Any]) -> "LatestQuote":
        return cls(
            item_id=item_id,
            high=_as_int(row.get("high")),
            high_time=_as_int(row.get("highTime")),
            low=_as_int(row.get("low")),
            low_time=_as_int(row.get("lowTime")),
        )

    @property
    def two_sided(self) -> bool:
        return self.high is not None and self.low is not None and self.low > 0

    def staleness_s(self, now: float) -> float | None:
        """Age of the *older* of the two sides. Both must be fresh to trust the spread."""
        times = [t for t in (self.high_time, self.low_time) if t is not None]
        if len(times) < 2:
            return None
        return max(0.0, now - min(times))


@dataclass(frozen=True, slots=True)
class WindowStat:
    """Volume-weighted averages and traded volume for one time bucket."""

    item_id: int
    avg_high: int | None
    high_volume: int
    avg_low: int | None
    low_volume: int

    @classmethod
    def from_payload(cls, item_id: int, row: dict[str, Any]) -> "WindowStat":
        return cls(
            item_id=item_id,
            avg_high=_as_int(row.get("avgHighPrice")),
            high_volume=_as_int(row.get("highPriceVolume")) or 0,
            avg_low=_as_int(row.get("avgLowPrice")),
            low_volume=_as_int(row.get("lowPriceVolume")) or 0,
        )

    @property
    def total_volume(self) -> int:
        return self.high_volume + self.low_volume

    @property
    def two_sided_volume(self) -> int:
        """The binding side. A flip needs both a willing seller and a willing buyer,
        so 10,000 buys against 3 sells is a 3-unit opportunity, not 10,003."""
        return min(self.high_volume, self.low_volume)


EMPTY_WINDOW = WindowStat(item_id=-1, avg_high=None, high_volume=0, avg_low=None, low_volume=0)


def parse_mapping(
    rows: Iterable[dict[str, Any]],
    exempt_names: frozenset[str] = DEFAULT_EXEMPT_ITEM_NAMES,
) -> dict[int, ItemMeta]:
    out: dict[int, ItemMeta] = {}
    for row in rows:
        meta = ItemMeta.from_mapping_row(row, exempt_names)
        if meta is not None:
            out[meta.item_id] = meta
    return out


def parse_latest(data: dict[str, dict[str, Any]]) -> dict[int, LatestQuote]:
    out: dict[int, LatestQuote] = {}
    for raw_id, row in data.items():
        item_id = _as_int(raw_id)
        if item_id is None or not isinstance(row, dict):
            continue
        out[item_id] = LatestQuote.from_payload(item_id, row)
    return out


def parse_window(data: dict[str, dict[str, Any]]) -> dict[int, WindowStat]:
    out: dict[int, WindowStat] = {}
    for raw_id, row in data.items():
        item_id = _as_int(raw_id)
        if item_id is None or not isinstance(row, dict):
            continue
        out[item_id] = WindowStat.from_payload(item_id, row)
    return out
