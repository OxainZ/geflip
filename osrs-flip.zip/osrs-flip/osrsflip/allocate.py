"""Spread a fixed bankroll across a fixed number of Grand Exchange slots.

Members get 8 slots, free players 3. That cardinality constraint is what makes
this more than "buy the top of the list": the highest gp/h item might only
absorb 200k of capital, and a slot spent on it is a slot not spent on something
that can soak up 20m.

Formally this is a bounded knapsack with a cardinality constraint, which is
NP-hard, so we do not pretend to solve it exactly:

  1. Greedy by *profit density* (expected gp/hour per gp of capital deployed),
     filling each pick to its buy-limit / throughput cap or to whatever capital
     remains, whichever binds first.
  2. A 1-for-1 swap local search over the top ``pool_size`` candidates, which
     fixes the classic greedy failure of burning all 8 slots on tiny high-ROI
     items while most of the bankroll sits idle.

Step 2 is cheap (a few thousand evaluations) and the result is reported with the
idle-capital figure so you can see when the constraint that is actually binding
is the market, not your gold.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

from .scoring import Candidate


@dataclass(slots=True)
class Position:
    candidate: Candidate
    quantity: int
    capital: int
    expected_gp_per_hour: float
    cycle_profit: int


@dataclass(slots=True)
class Allocation:
    positions: list[Position]
    bankroll: int
    slots: int

    @property
    def capital_deployed(self) -> int:
        return sum(p.capital for p in self.positions)

    @property
    def capital_idle(self) -> int:
        return self.bankroll - self.capital_deployed

    @property
    def expected_gp_per_hour(self) -> float:
        return sum(p.expected_gp_per_hour for p in self.positions)

    @property
    def expected_cycle_profit(self) -> int:
        return sum(p.cycle_profit for p in self.positions)

    @property
    def slots_used(self) -> int:
        return len(self.positions)

    @property
    def binding_constraint(self) -> tuple[str, str]:
        """Which resource ran out first, and what to do about it.

        gp/hour and return-per-gp rank completely differently. Which one you
        should optimise depends entirely on this answer.
        """
        idle_frac = self.capital_idle / self.bankroll if self.bankroll else 0.0
        if self.slots_used >= self.slots and idle_frac > 0.10:
            return ("slots", "All slots are full with capital left over. More gold "
                             "will not help; rank by gp/hour to maximise each slot.")
        if idle_frac <= 0.05:
            return ("capital", "Your bank is fully deployed. Rank by %/hour instead "
                               "— with limited gold you want return per gp.")
        return ("market", "Capital and slots are both spare: not enough items pass "
                          "your filters or absorb the volume. Loosen the gates.")

    @property
    def gp_per_million_deployed(self) -> float:
        dep = self.capital_deployed
        return self.expected_gp_per_hour / (dep / 1_000_000) if dep else 0.0

    @property
    def return_on_deployed(self) -> float:
        """Expected profit per 4h cycle divided by capital at risk."""
        deployed = self.capital_deployed
        return self.expected_cycle_profit / deployed if deployed else 0.0


def _unit_cap(candidate: Candidate) -> int:
    """Units obtainable per cycle ignoring capital: the binding market constraint."""
    return max(0, min(candidate.buy_limit, candidate.throughput_cap))


def _density(candidate: Candidate, cycle_hours: float) -> float:
    """Expected gp/hour generated per gp of capital tied up."""
    if candidate.buy_price <= 0:
        return 0.0
    return (candidate.margin * candidate.confidence / cycle_hours) / candidate.buy_price


def _fill(
    picks: Sequence[Candidate],
    bankroll: int,
    cycle_hours: float,
    max_item_fraction: float = 1.0,
) -> tuple[list[Position], int]:
    """Size a fixed set of picks against the bankroll, richest density first."""
    ordered = sorted(picks, key=lambda c: -_density(c, cycle_hours))
    remaining = bankroll
    per_item_cap = int(bankroll * max_item_fraction)
    positions: list[Position] = []

    for cand in ordered:
        if remaining <= 0 or cand.buy_price <= 0:
            continue
        spendable = min(remaining, per_item_cap)
        qty = min(_unit_cap(cand), spendable // cand.buy_price)
        if qty <= 0:
            continue
        capital = qty * cand.buy_price
        cycle_profit = cand.margin * qty
        positions.append(
            Position(
                candidate=cand,
                quantity=qty,
                capital=capital,
                expected_gp_per_hour=(cycle_profit / cycle_hours) * cand.confidence,
                cycle_profit=cycle_profit,
            )
        )
        remaining -= capital

    total = sum(p.expected_gp_per_hour for p in positions)
    return positions, int(total)


def allocate(
    candidates: Sequence[Candidate],
    *,
    bankroll: int,
    slots: int = 8,
    cycle_hours: float = 4.0,
    max_item_fraction: float = 1.0,
    pool_size: int = 150,
    max_swap_rounds: int = 25,
) -> Allocation:
    """Choose up to ``slots`` items and size each against ``bankroll``."""
    if slots < 1:
        raise ValueError("slots must be at least 1")
    if not 0.0 < max_item_fraction <= 1.0:
        raise ValueError("max_item_fraction must be in (0, 1]")
    if not 0.0 < max_item_fraction <= 1.0:
        raise ValueError("max_item_fraction must be in (0, 1]")
    if bankroll <= 0 or not candidates:
        return Allocation(positions=[], bankroll=max(0, bankroll), slots=slots)

    pool = [c for c in candidates[:pool_size] if _unit_cap(c) > 0 and c.buy_price > 0]
    if not pool:
        return Allocation(positions=[], bankroll=bankroll, slots=slots)

    # --- 1. greedy seed by density ---------------------------------------
    by_density = sorted(pool, key=lambda c: -_density(c, cycle_hours))
    per_item_cap = int(bankroll * max_item_fraction)
    chosen: list[Candidate] = []
    remaining = bankroll
    for cand in by_density:
        if len(chosen) >= slots:
            break
        spendable = min(remaining, per_item_cap)
        if spendable // cand.buy_price <= 0:
            continue
        chosen.append(cand)
        remaining -= min(_unit_cap(cand), spendable // cand.buy_price) * cand.buy_price

    positions, best = _fill(chosen, bankroll, cycle_hours, max_item_fraction)

    # --- 2. 1-for-1 swap local search ------------------------------------
    chosen_ids = {c.item_id for c in chosen}
    bench = [c for c in pool if c.item_id not in chosen_ids]

    for _ in range(max_swap_rounds):
        improved = False
        for i in range(len(chosen)):
            for challenger in bench:
                trial = list(chosen)
                trial[i] = challenger
                trial_positions, trial_score = _fill(
                    trial, bankroll, cycle_hours, max_item_fraction)
                if trial_score > best:
                    evicted = chosen[i]
                    chosen = trial
                    positions, best = trial_positions, trial_score
                    bench = [c for c in bench if c.item_id != challenger.item_id]
                    bench.append(evicted)
                    improved = True
                    break
            if improved:
                break

        # Adding a spare item is free when a slot is idle and capital is left.
        if not improved and len(chosen) < slots:
            for challenger in bench:
                trial = list(chosen) + [challenger]
                trial_positions, trial_score = _fill(
                    trial, bankroll, cycle_hours, max_item_fraction)
                if trial_score > best:
                    chosen = trial
                    positions, best = trial_positions, trial_score
                    bench = [c for c in bench if c.item_id != challenger.item_id]
                    improved = True
                    break

        if not improved:
            break

    positions.sort(key=lambda p: -p.expected_gp_per_hour)
    return Allocation(positions=positions, bankroll=bankroll, slots=slots)
