"""Position book: what you actually bought, and what you can still buy.

Two mechanics drive everything here, and both are easy to model wrongly.

**The 4-hour window anchors to your FIRST purchase, not a rolling lookback.**
Buy 1,000 at 10:00 and 12,000 at 13:55 and the whole allowance resets at 14:00 —
five minutes later — because the window opened with that first unit. A naive
"sum of everything bought in the last four hours" would still be counting the
12,000 and would wrongly block the item. Windows are consecutive, so they have
to be replayed in order.

**Dose variants share one allowance.** Prayer potion (1) through (4) draw from
the same 2,000. Buying the 4-dose exhausts the 1-dose. Grouping is deliberately
narrow — a single digit in parentheses at the end of the name — because
suffixes like "(g)" and "(or)" are cosmetic variants with their own limits.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Iterable, Mapping, Sequence

from .numeric import round_half_up
from .tax import net_proceeds

LIMIT_WINDOW_S = 4 * 3600

_DOSE_SUFFIX = re.compile(r"^(.*?)\s*\([1-6]\)$")


def limit_group(name: str | None) -> str:
    """Shared-allowance key. 'Prayer potion(4)' -> 'prayer potion'."""
    text = (name or "").strip()
    match = _DOSE_SUFFIX.match(text)
    return (match.group(1) if match else text).strip().lower()


@dataclass(slots=True)
class Position:
    pid: int
    item_id: int
    name: str
    qty: int
    buy_price: int
    bought_at: float
    sold_qty: int = 0
    sell_price: int | None = None
    sold_at: float | None = None
    tax_exempt: bool = False

    @property
    def open_qty(self) -> int:
        return max(0, self.qty - self.sold_qty)

    @property
    def is_open(self) -> bool:
        return self.open_qty > 0


@dataclass(slots=True)
class LimitState:
    spent: int
    remaining: int
    reset_at: float | None
    is_open: bool
    group: str = ""
    shared: bool = False


def limit_for(
    positions: Sequence[Position],
    item_id: int,
    limit: int | float,
    now: float,
    group: str | None = None,
) -> LimitState:
    """Replay consecutive 4h windows and report the state of the current one."""
    if group is None:
        relevant = [p for p in positions if p.item_id == item_id]
    else:
        relevant = [p for p in positions if limit_group(p.name) == group]
    relevant.sort(key=lambda p: p.bought_at)

    window_start: float | None = None
    spent = 0
    for pos in relevant:
        if window_start is None or pos.bought_at >= window_start + LIMIT_WINDOW_S:
            window_start = pos.bought_at
            spent = 0  # a new window opened
        spent += pos.qty

    if window_start is None or now >= window_start + LIMIT_WINDOW_S:
        cap = limit if limit != float("inf") else 0
        return LimitState(
            spent=0,
            remaining=int(cap) if limit != float("inf") else 2**31,
            reset_at=None,
            is_open=False,
            group=group or "",
        )

    remaining = limit - spent if limit != float("inf") else 2**31
    return LimitState(
        spent=spent,
        remaining=max(0, int(remaining)),
        reset_at=window_start + LIMIT_WINDOW_S,
        is_open=True,
        group=group or "",
    )


def limit_map(
    positions: Sequence[Position],
    mapping: Mapping[int, Any],
    now: float,
) -> dict[int, LimitState]:
    """Constrain every item that shares an allowance with something held.

    Names drive the grouping, so they are resolved from the mapping rather than
    trusted from whatever was stored alongside the position.
    """
    if not positions or not mapping:
        return {}

    resolved: list[Position] = []
    for pos in positions:
        name = pos.name or getattr(mapping.get(pos.item_id), "name", "")
        if not name:
            continue
        resolved.append(
            Position(
                pid=pos.pid, item_id=pos.item_id, name=name, qty=pos.qty,
                buy_price=pos.buy_price, bought_at=pos.bought_at,
                sold_qty=pos.sold_qty, sell_price=pos.sell_price,
                sold_at=pos.sold_at, tax_exempt=pos.tax_exempt,
            )
        )
    if not resolved:
        return {}

    held_groups = {limit_group(p.name) for p in resolved}
    out: dict[int, LimitState] = {}
    for item_id, meta in mapping.items():
        group = limit_group(getattr(meta, "name", ""))
        if group not in held_groups:
            continue
        cap = getattr(meta, "buy_limit", None)
        state = limit_for(
            resolved, item_id, cap if cap is not None else float("inf"), now, group
        )
        state.group = group
        state.shared = any(
            limit_group(p.name) == group and p.item_id != item_id for p in resolved
        )
        out[item_id] = state
    return out


@dataclass(slots=True)
class PnL:
    cost: int
    realised: int
    open_qty: int
    unrealised: int | None
    mark: int | None

    @property
    def total(self) -> int:
        return self.realised + (self.unrealised or 0)


def position_pnl(pos: Position, mark: int | None = None) -> PnL:
    """Realised and unrealised profit, tax correct on the sell side."""
    cost = pos.buy_price * pos.qty
    realised = 0
    if pos.sold_qty and pos.sell_price is not None:
        realised = (
            net_proceeds(pos.sell_price, exempt=pos.tax_exempt) - pos.buy_price
        ) * pos.sold_qty

    unrealised: int | None = None
    if pos.open_qty > 0 and mark is not None:
        unrealised = (
            net_proceeds(mark, exempt=pos.tax_exempt) - pos.buy_price
        ) * pos.open_qty

    return PnL(
        cost=cost, realised=realised, open_qty=pos.open_qty,
        unrealised=unrealised, mark=mark,
    )


def blend_sale(pos: Position, qty: int, price: int) -> Position:
    """Fold a partial sale into a weighted-average sell price."""
    if qty <= 0:
        raise ValueError("sale quantity must be positive")
    if qty > pos.open_qty:
        raise ValueError(f"cannot sell {qty}; only {pos.open_qty} held")
    prev_qty, prev_px = pos.sold_qty, pos.sell_price or 0
    pos.sold_qty = prev_qty + qty
    pos.sell_price = round_half_up((prev_px * prev_qty + price * qty) / pos.sold_qty)
    return pos


def rolling_reset_schedule(
    positions: Sequence[Position], mapping: Mapping[int, Any], now: float
) -> list[tuple[str, LimitState]]:
    """Open allowances, soonest reset first — the scheduling view."""
    states = limit_map(positions, mapping, now)
    by_group: dict[str, LimitState] = {}
    labels: dict[str, set[str]] = {}
    for item_id, state in states.items():
        if not state.is_open:
            continue
        by_group.setdefault(state.group, state)
    for pos in positions:
        labels.setdefault(limit_group(pos.name), set()).add(pos.name)

    rows = [
        (" + ".join(sorted(labels.get(group, {group}))), state)
        for group, state in by_group.items()
    ]
    rows.sort(key=lambda row: row[1].reset_at or 0)
    return rows
