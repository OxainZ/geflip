import json, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
from osrsflip.models import parse_mapping, parse_latest, parse_window
from osrsflip.scoring import ScanConfig, score_candidates
from osrsflip.book import Position, limit_map
from osrsflip.allocate import allocate

F = json.load(open(os.path.join(HERE, 'fixture.json')))
now = F['now']; c = F['config']
mapping = parse_mapping(F['mapping'])
cfg = ScanConfig(
    bankroll=c['bankroll'], slots=c['slots'], members=c['members'],
    min_hourly_volume=c['minVol'], min_daily_volume=c['minVol24'],
    max_quote_age_s=c['maxAgeS'], min_margin_gp=c['minMargin'],
    min_unit_price=c['minPrice'], max_unit_price=c['maxPrice'],
    slippage=c['slip'], participation=c['part'],
    max_capital_fraction_per_item=c['maxFrac'], staleness_tau_s=c['tauS'],
    volume_saturation=c['volSat'], unverified_haircut=c['haircut'],
    cycle_hours=c['cycleH'],
)
positions = [Position(pid=i, item_id=p['itemId'], name=p['name'], qty=p['qty'],
                      buy_price=p['buyPrice'], bought_at=now + p['boughtAtOffset'],
                      sold_qty=p['soldQty'], sell_price=p['sellPrice'],
                      tax_exempt=bool(p['exempt']))
             for i, p in enumerate(F['positions'], 1)]
cands = score_candidates(mapping, parse_latest(F['latest']), parse_window(F['hourly']),
                         parse_window(F['daily']), parse_window(F['fiveMin']), cfg, now=now,
                         limits=limit_map(positions, mapping, now))
out = [dict(id=x.item_id, buy=x.buy_price, sell=x.sell_price, margin=x.margin,
            tax=x.tax_per_unit, qty=x.quantity, capital=x.capital_required,
            gph=round(x.expected_gp_per_hour), roiHr=round(x.roi_per_hour, 9),
            conf=round(x.confidence, 9), bid=x.bid_competitive, ask=x.ask_competitive,
            marginComp=x.margin_competitive, check=x.margin_check_cost,
            bottleneck=x.bottleneck, fillBuy=round(x.fill_buy_minutes, 6),
            fillSell=round(x.fill_sell_minutes, 6),
            trend1h=None if x.trend_1h is None else round(x.trend_1h, 9),
            activity=None if x.activity is None else round(x.activity, 9),
            flowFcast=round(x.flow_forecast, 6),
            slipObs=None if x.slippage_observed is None else round(x.slippage_observed, 9),
            breakeven=x.breakeven_sell,
            bound={'buy limit':'buy limit','capital':'capital',
                   'market throughput':'throughput'}[x.limiting_factor])
       for x in cands]
a = allocate(cands, bankroll=cfg.bankroll, slots=cfg.slots,
             max_item_fraction=cfg.max_capital_fraction_per_item)
print(json.dumps({'cands': out,
                  'alloc': {'deployed': a.capital_deployed, 'slots': a.slots_used}}, indent=1))
