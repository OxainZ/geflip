const fs=require('fs');
const path=require('path');
const HERE=__dirname;
const F=JSON.parse(fs.readFileSync(path.join(HERE,'fixture.json'),'utf8'));
const HTML=process.argv[2] || path.join(HERE,'..','geflip.html');
if(!fs.existsSync(HTML)){ console.error('no such file: '+HTML); process.exit(2); }
const js=fs.readFileSync(HTML,'utf8').match(/<script>\n([\s\S]*)<\/script>/)[1];
const el=()=>new Proxy({style:{},classList:{add(){},remove(){},toggle(){}},dataset:{},addEventListener(){},
  innerHTML:'',textContent:'',value:'',checked:true,querySelectorAll:()=>[],closest:()=>null,
  getContext:()=>new Proxy({},{get:()=>()=>{}}),getAttribute:()=>'190',clientWidth:320,setAttribute(){}},
  {get:(t,p)=>p in t?t[p]:'',set:(t,p,v)=>{t[p]=v;return true}});
global.document={getElementById:el,querySelectorAll:()=>[],querySelector:el,addEventListener(){},hidden:false};
global.window={devicePixelRatio:1}; global.navigator={clipboard:{writeText:async()=>{}}};
global.fetch=async()=>{throw new Error('x')}; global.confirm=()=>false; global.prompt=()=>null;
const mod={exports:{}};
new Function('module','exports','window','localStorage',
  js+"\nmodule.exports={scoreAll,indexMapping,limitMap,allocate};")(mod,mod.exports,global.window,undefined);
const E=mod.exports;
const now=F.now;
const map=E.indexMapping(F.mapping);
const pos=F.positions.map(p=>({...p, boughtAt: now + p.boughtAtOffset}));
const {cands}=E.scoreAll(map,F.latest,F.hourly,F.daily,null,F.config,now,E.limitMap(pos,map,now));
const out=cands.map(c=>({
  id:c.id, buy:c.buy, sell:c.sell, margin:c.margin, tax:c.tax, qty:c.quantity,
  capital:c.capital, gph:Math.round(c.expGph), roiHr:+c.roiHr.toFixed(9),
  conf:+c.confidence.toFixed(9), bid:c.bidComp, ask:c.askComp,
  marginComp:c.marginComp, check:c.checkCost, bottleneck:c.bottleneck,
  fillBuy:+c.fillBuyMin.toFixed(6), fillSell:+c.fillSellMin.toFixed(6),
  trend1h:c.trend1h==null?null:+c.trend1h.toFixed(9),
  activity:c.activity==null?null:+c.activity.toFixed(9),
  flowFcast:+c.flowFcast.toFixed(6),
  breakeven:c.breakeven, bound:c.bound,
}));
const alloc=E.allocate(cands,F.config.bankroll,F.config.slots,F.config.maxFrac);
console.log(JSON.stringify({cands:out,
  alloc:{deployed:alloc.pos.reduce((s,p)=>s+p.capital,0), slots:alloc.pos.length}},null,1));
