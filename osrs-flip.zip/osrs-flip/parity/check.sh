#!/usr/bin/env bash
# Prove the Python engine and the browser engine agree exactly.
# Two implementations of the same model drift silently; this makes it loud.
set -euo pipefail
cd "$(dirname "$0")"
HTML="${1:-../geflip.html}"
node run_js.js "$HTML" > /tmp/js.json
python3 run_py.py > /tmp/py.json
python3 - <<'PY'
import json, sys
js=json.load(open('/tmp/js.json')); py=json.load(open('/tmp/py.json'))
jc={c['id']:c for c in js['cands']}; pc={c['id']:c for c in py['cands']}
bad=[]
if set(jc)!=set(pc): bad.append(f"surviving items differ: {set(jc)^set(pc)}")
for i in sorted(set(jc)&set(pc)):
    for k in jc[i]:
        a,b=jc[i][k],pc[i][k]
        if a!=b and not (isinstance(a,float) and isinstance(b,float) and abs(a-b)<1e-6):
            bad.append(f"item {i} {k}: JS={a!r} PY={b!r}")
if js['alloc']!=py['alloc']: bad.append(f"allocation: {js['alloc']} vs {py['alloc']}")
if bad:
    print("PARITY FAILED"); [print("  "+b) for b in bad]; sys.exit(1)
print(f"PARITY OK — {len(jc)} items, {len(next(iter(jc.values())))} fields each, identical")
PY
