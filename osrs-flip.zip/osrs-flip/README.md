# osrsflip

Ranks Old School RuneScape Grand Exchange flips by **expected gp per hour** and
by **return per gp deployed**, with the 2% sale tax, connected 4-hour buy limits,
order flow, price drift and quote staleness all priced in. Tells you the exact
prices to post, tracks what you actually bought, and journals every pick so you
can find out later whether the margins it promised were real.

Stdlib only. No dependencies, no API key, no client plugin.

A browser version of the same engine lives in `geflip.html`. `parity/check.sh`
proves the two produce identical output on a shared fixture — two
implementations of one model drift silently otherwise.

---

## Why not just sort by margin

Every flip site sorts by spread or ROI, and both are misleading:

| Trap | What actually happens | How this handles it |
|---|---|---|
| Quoted spread | 2% comes off the sell side, so a 2% spread is break-even | Exact integer tax math, 5M cap, exemptions |
| High ROI% | 40% on an item with a buy limit of 6 is pocket change | Ranks on gp/hour after limit and capital |
| Wide spread | Often means nobody trades it, so nothing fills | Two-sided hourly + daily volume gates |
| One lucky print | A single outlier trade fakes a huge margin | Margin is `min(latest spread, 1h VWAP spread)` |
| Stale quote | The price is from 3 hours ago and is gone | Hard age cutoff plus exponential freshness decay |
| 8 slots | Best gp/h item may only absorb 200k of your bankroll | Slot allocator with a capacity-aware local search |
| gp/hour | Secretly ranks by "what absorbs the most gold" | `%/h` column: return per gp, independent of size |
| Buy limits | Tools recommend items you already exhausted | Position book with connected 4h window tracking |
| Falling price | A wide spread on a collapsing item is not a flip | Drift vs 1h and 24h, with a falling-knife penalty |
| Which price? | "Buy at low" will sit unfilled behind the queue | Competitive offer prices, one tick inside |

---

## Install

```bash
cd osrs-flip
export OSRS_FLIP_UA="osrs-flip-scanner - discord:yourname"   # required by the wiki
python -m osrsflip scan --bankroll 50m --slots 8
```

Optional editable install: `pip install -e .` gives you an `osrsflip` command.

The OSRS Wiki asks every automated client to send a descriptive User-Agent with
contact info. The client **refuses to start without one** rather than getting the
whole tool blocked.

---

## Commands

```bash
# Rank flips right now and propose a slot allocation
python -m osrsflip scan --bankroll 50m --slots 8

# Free-to-play, small bank, and assume 0.5% adverse fills
python -m osrsflip scan --bankroll 2m --slots 3 --f2p --slippage 0.005

# See why items were filtered out (essential when the list comes back empty)
python -m osrsflip scan --explain

# Machine-readable output for your own tooling
python -m osrsflip scan --json

# Replay history against picks made 8+ hours ago
python -m osrsflip verify --horizon 8

# Predicted vs realized across everything verified so far
python -m osrsflip stats --allocated-only

# Drill into one item
python -m osrsflip item "Abyssal whip" --timestep 1h

# The exact prices to post, with order flow and fill times
python -m osrsflip scan --offers

# Log what actually filled; this starts the 4h buy-limit window
python -m osrsflip buy "Teak plank" 13000 800
python -m osrsflip sell 1 13000 825

# Open positions, tax-correct realised and unrealised p&l
python -m osrsflip book

# Buy limit timers, soonest reset first
python -m osrsflip limits
```

## Which price do I actually post?

`--offers` answers this. The GE matches better prices first, and among equal
prices the **older** offer wins — so a tick is not overpaying, it is what buys
you priority over everyone already queued at that price.

```
item        patient buy/sell   competitive buy/sell   margin  sellers/buyers  slower leg
Teak plank  800 / 825          801 / 824                   7  41,000 / 38,000 sell
```

Two consequences worth internalising:

* **Overbidding is free when supply is already resting.** The GE refunds the
  difference to whoever placed the *newer* offer, so a 1-unit margin check at
  +20% costs you only the spread. `margin check costs` prices that per item.
* **Never overbid on an offer you intend to rest.** The refund goes to the newer
  offer, so if your inflated bid sits there and a seller dumps into it, *they*
  get your price.

## Buy limits are the mechanic most tools get wrong

The window opens on your **first** purchase and resets exactly 4h later,
whatever time the rest fills. Buy 1,000 at 10:00 and 12,000 at 13:55 and
everything resets at 14:00 — five minutes later. A rolling "last four hours"
sum would still be blocking the item. Windows are consecutive and are replayed
in order; there is a test asserting exactly this divergence.

Two consequences:

* **Front-load every window.** Buying early costs nothing and gets your next
  allocation sooner.
* **Stagger your eight items** so something frees up every 30-60 minutes
  instead of all eight going idle at once. `limits` is the scheduling view.

Dose variants share one allowance — Prayer potion (1) through (4) draw from the
same 2,000 — so the book groups them. The grouping is deliberately narrow: a
single digit in parentheses at the end of a name. `Rune platebody (g)` and
`Amulet of fury (or)` are cosmetic variants with their own limits and are
explicitly tested against being swallowed.

## gp/hour or %/hour?

They rank completely differently and the right one depends on what you run out
of first. `scan` prints the answer:

* **Gold runs out first** (bank fully deployed) → rank by `%/h`. Return per gp
  is what matters.
* **Slots run out first** (8 full, gold idle) → rank by `gp/h`. Extra gold is
  worthless; each slot should earn its maximum.
* **Market runs out first** (both spare) → your filters are too tight.

A concrete case: teak planks tie up 10.4m to make 27.8k/h (2,675 per 1m
deployed); fire runes tie up 250k to make 11.9k/h (47,561 per 1m). The plank
looks 2.3x better and is 18x worse per gold. `--max-item-fraction` defaults to
0.25 so no single item can swallow the bank.

Run `demo_offline.py` to exercise the entire pipeline against a synthetic market
with no network calls — useful for testing scoring changes.

---

## How the score is built

For each item with a two-sided quote:

```
buy       = latest insta-sell price   (adjusted up by --slippage)
sell      = latest insta-buy price    (adjusted down by --slippage)
tax       = min(floor(sell * 0.02), 5_000_000)   0 if exempt or sell < 50
margin    = min(latest margin, 1h VWAP margin)   <- the pessimism that matters
quantity  = min(buy limit, bankroll // buy, participation * vol_1h * 4h)
gp/hour   = margin * quantity / 4
expected  = gp/hour * confidence
```

`confidence ∈ [0,1]` is the product of three terms, so any single bad signal
drags it down:

- **freshness** `exp(-quote_age / 20min)` — how recently both sides traded
- **volume** `sqrt(min(1, vol_1h / 200))` — concave, so more volume helps with
  diminishing returns
- **stability** — agreement between the instantaneous spread and the hourly
  VWAP spread. Near zero when a single outlier print is inflating the margin.

Confidence is a multiplier, not a filter, so marginal items still appear and you
can judge them yourself.

### Slot allocation

Choosing ≤ N items and sizing each is a bounded knapsack with a cardinality
constraint — NP-hard, so this does not claim optimality. It seeds greedily by
profit density (expected gp/h per gp deployed), then runs a 1-for-1 swap local
search over the top 150 candidates. The swap pass exists because pure greedy
loves to burn all 8 slots on tiny high-ROI items while most of the bankroll sits
idle. Idle capital is always reported so you can see when the market, not your
gold, is the binding constraint.

---

## Calibrating slippage — the part that makes this honest

`--slippage` defaults to **0**, which is optimistic: it assumes you fill at the
last traded prices. Do not leave it there.

1. Run `scan` a few times a day for a week. Every pick is journalled.
2. Run `verify --horizon 8` daily.
3. Run `stats`. Compare `mean predicted roi` to `mean realized roi`.
4. Set `--slippage` to roughly half the shortfall (it applies to both sides).

`verify` asks whether the prices were *reachable* in the item's own history: did
anything print at or below your buy, and later at or above your sell. It does
**not** model queue position, partial fills, or the other flippers reading the
same public feed. Realized ROI from `stats` is therefore a **ceiling**, and the
gap between it and your actual results is your true execution cost.

---

## Data and rules

Source: the OSRS Wiki / RuneLite real-time prices API
(`prices.runescape.wiki/api/v1/osrs`), a partnership between the wiki and
RuneLite that aggregates transactions seen by RuneLite clients.

- `/mapping` item metadata including buy limits (cached 24h on disk)
- `/latest` most recent insta-buy and insta-sell per item
- `/5m`, `/1h`, `/24h` VWAP and traded volume per window
- `/timeseries` history for one item, used by `verify`

GE tax rules encoded in `tax.py`, verified July 2026:

- 2% of the sale price, seller only — **not 1%**, it rose from 1% on 29 May 2025
- floored per item, so anything under 50 gp is untaxed
- capped at 5,000,000 gp **per item**, not per offer
- bonds and a short list of starter tools are exempt

The exemption list is a `frozenset` in `tax.py`. Jagex has changed it before;
refresh it from the wiki if you trade tools.

---

## Known limitations

- **`/latest` is not an order book.** There is no depth behind either price. The
  computed margin is what the last two trades imply, not what you can fill.
- **The feed is public.** Everyone else runs the same numbers, so the top of the
  list is the most crowded trade on it. Your realistic edge is mid-tier: items
  too thin for the mass flippers, liquid enough to cycle.
- **Volume is RuneLite-visible only**, so it understates true market activity by
  an unknown, item-dependent factor.
- **`participation` (default 10%) is a guess.** It is the single least grounded
  parameter in the model. Calibrate it from your own fills.
- **Verify within a day.** `/timeseries` returns at most 365 points, so the
  5-minute series only reaches back about 30 hours. Past that a pick can never
  be graded and the calibration data is gone. `verify` warns at 22 hours.
- **Connected limits beyond doses are not modelled.** The API does not expose
  the groupings, so only the `(1)`-`(6)` dose pattern is handled.
- **The naive t-stat in `stats` assumes independent observations**, which is
  false — the same item across consecutive scans is one bet, and market-wide
  moves correlate everything. Smoke alarm, not a p-value.
- Nothing here automates the game client, and you should not make it do so.

---

## Layout

```
osrsflip/
  api.py        HTTP client: retries, backoff, disk cache, UA enforcement
  tax.py        GE tax, exemptions, break-even solver (exact integer math)
  models.py     Parsing and validation of the loose JSON payloads
  book.py       Buy-limit windows, connected dose limits, position p&l
  scoring.py    Candidate scoring, offer prices, flow, drift, confidence
  allocate.py   Bankroll across slots: density greedy + swap local search
  journal.py    SQLite pre-registration, positions, forward verification
  fmt.py        gp abbreviation, tables, duration
  cli.py        argparse front end
tests/          103 tests, stdlib unittest
parity/         cross-checks this engine against the browser build
demo_offline.py Full pipeline on a synthetic market, no network
```

```bash
python -m unittest discover -s tests -t .   # 103 tests
./parity/check.sh ../geflip.html            # engines must agree exactly
python demo_offline.py                      # end to end, no network
```
